<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./font/fontawesome-free-6.3.0-web/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css"
    href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>

  <!-- Các tài nguyên SweetAlert2 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>

  <title>ADMIN</title>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="./css/admin1.css">
  <link rel="stylesheet" href="./css/reset.css">
  <style>
    .card {
      background-image: linear-gradient(to bottom right, #40a355e8, #ffbf00);
      transition: background-image 0.3s ease;
      color: #fff;
    }

    .card-text:last-child {
      font-size: 1rem;
    }
  </style>
</head>

<body id="show_home">
  <div id="add-product-form" style="display:none;" class="form_add">
    <form class="form_container">

      <h2>Thêm sản phẩm</h2>
      <div class="form-group">
        <label for="tensp">Tên sản phẩm:</label>
        <input type="text" class="form-control" id="tensp" name="tensp">
      </div>

      <div class="form-group">
        <label for="giasp">Giá sản phẩm:</label>
        <input type="text" class="form-control" id="giasp" name="giasp">
      </div>

      <div class="form-group">
        <label for="giamgia">Giảm giá:</label>
        <input type="text" class="form-control" id="giamgia" name="giamgia">
      </div>

      <div class="form-group">
        <label for="thongtinngan">Thông tin ngắn:</label>
        <textarea class="form-control" rows="1" cols="50" id="thongtinngan" name="thongtinngan"></textarea>
      </div>

      <div class="form-group">
        <label for="thongtinchitiet">Thông tin chi tiết:</label>
        <textarea class="form-control" rows="1" cols="50" id="thongtinchitiet" name="thongtinchitiet"></textarea>
      </div>

      <div class="form-group">
        <label for="loaisp">Loại thuốc:</label>
        <select class="form-control" id="loaisp">
          <option>giảm đau hạ sốt</option>
          <option>thuốc ho</option>
          <option>tai_mui_hong</option>
          <option>vitamin</option>
          <option>bo_gan</option>
          <option>bo_nao</option>
          <option>nhiet_ke</option>
          <option>thu_duong</option>
          <option>huyet_ap</option>
          <option>duong_da</option>
          <option>chong_nang</option>
          <option>sua_rua_mat</option>
        </select>
      </div>

      <div class="form-group">
        <label for="cachdonggoi">Cách đóng gói:</label>
        <input type="text" class="form-control" id="cachdonggoi" name="cachdonggoi">
      </div>

      <div class="form-group">
        <label for="soluong">Số lượng:</label>
        <input type="text" class="form-control" id="soluong" name="soluong">
      </div>

      <div class="form-group">
        <label for="hinhsp">Hình mô tả thuốc (link của hình):</label>
        <input type="text" class="form-control" id="hinhsp" name="hinhsp">
      </div>

      <div class="form_actions">
        <div class="mx-auto">
          <button id="submit-btn" class="btn btn-primary">Thêm</button>
          <button id="cancel-btn" class="btn btn-secondary">Hủy</button>
        </div>
      </div>
    </form>
  </div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
  <script>
    $(document).ready(function () {
      $("#add_show_admin").on("click", function () {
        $("#add-product-form").css("display", "block");
      });
    });
    $(document).ready(function () {
      $("#dangxuat").on("click", function () {
        window.location.href = "./index.php";
      });
    });
  </script>

  </script>
  </div>

  <div class="form_add" id="upd-product-form" style="display:none;">
    <form class="form_container">
      <h2>Cập nhật sản phẩm</h2>

      <label for="tensp">Tên sản phẩm:</label>
      <input type="text" id="ten" name="tensp"><br>

      <label for="giasp">Giá sản phẩm:</label>
      <input type="text" id="gia" name="giasp"><br>

      <label for="giamgia">Giảm giá:</label>
      <input type="text" id="giamgia_sp" name="giamgia"><br>

      <label for="thongtinngan">Thông tin ngắn:</label>
      <textarea rows="1" cols="50" type="text" id="ngan" name="thongtinngan"></textarea><br>

      <label for="thongtinchitiet">Thông tin chi tiết:</label>
      <textarea rows="1" cols="50" id="chitiet" name="thongtinchitiet"></textarea><br>

      <label for="loaisp">Loại thuốc:</label>
      <select id="loaisp">
        <option>giảm đau hạ sốt</option>
        <option>thuốc ho</option>
        <option>tai_mui_hong</option>
        <option>vitamin</option>
        <option>bo_gan</option>
        <option>bo_nao</option>
        <option>nhiet_ke</option>
        <option>thu_duong</option>
        <option>huyet_ap</option>
        <option>duong_da</option>
        <option>chong_nang</option>
        <option>sua_rua_mat</option>
      </select>

      <label for="cachdonggoi">Cách đóng gói:</label>
      <input type="text" id="donggoi" name="cachdonggoi"><br>

      <label for="soluong">Số lượng:</label>
      <input type="text" id="sl" name="soluong"><br>

      <label for="hinhsp">Hình mô tả thuốc (link của hình):</label>
      <input type="text" id="hinh" name="hinhsp"><br>

      <div class="form_actions">
        <div class="mx-auto">
          <button id="update-btn" class="btn btn-primary">Cập nhật</button>
          <button class="btn btn-secondary">Hủy</button>
        </div>
      </div>
    </form>
  </div>


  <div class="row">
    <div class="col_3">
      <div class="logo">
        <a href="./index.php">
          <img style="display: block; margin: 0 auto;" src="./img/logotrang.png" alt="Ảnh logo" width="40%">
        </a>
      </div>
      <div class="menu">

      </div>
    </div>
    <div class="col_9">
      <div class="header" style="background-color: #fff">
        <form id="search-form">
          <!-- <span class="search-icon"><i class="fas fa-search"></i></span> -->
          <input id="input_search" class="input_search" type="text" placeholder="Tìm kiếm...">
          <button id="btn_search" type="submit">Tìm kiếm</button>
        </form>
        <div class="user">
          <img src="./img/user.svg" alt="user" width="20px" height="20px">
          <p id="user_name" style="width: 140px;">
            <!-- Hiển thị tên đăng nhập -->
            <script>
              var user = localStorage.getItem('user');
              document.getElementById('user_name').innerHTML = user;
            </script>
          </p>

          <div class="user_account">
            <ul>
              <li>
                <i class="fa-solid fa-gear"></i>
                <button class="bt_user">Cài đặt</button>
              </li>
              <li>
                <i class="fa-solid fa-right-from-bracket"></i>
                <button id="dangxuat" class="bt_user">Đăng xuất</button>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="container_product" id="product_boss">
        <div class="tilte">
          <p id="title_quanly"></p>
          <button style="display:none;" id="add_show_admin" class="bt_add">Thêm</button>
        </div>


        <?php
        // Thông tin kết nối đến cơ sở dữ liệu
        include "./php/connect.php";

        $email = $_GET['email'];

        // Lấy dữ liệu từ cơ sở dữ liệu
        $sql = "SELECT * FROM hoadon WHERE email_kh LIKE '$email' ORDER BY ngaymua DESC";
        $result = mysqli_query($conn, $sql);

        $table = '
          <div class="cart_product_title scrollbar">
          <table>
          <thead class="table_fixed">
            <tr>
              <th>Mã ĐH</th>
              <th>Tài khoản KH</th>
              <th>Ngày đặt</th>
              <th>Tổng tiền</th>
              <th>Địa chỉ giao hàng</th>
              <th>Trạng thái đơn hàng</th>
              <th></th>
            </tr>
          </thead>
          <tbody>';

        // Kiểm tra kết quả truy vấn
        if (mysqli_num_rows($result) > 0) {
          // Lấy các giá trị cần thiết từ hàng dữ liệu đầu tiên (giả sử chỉ có 1 sản phẩm)
          while ($row = mysqli_fetch_assoc($result)) {
            $ma = $row["ma_hoadon"];
            $emai = $row["email_kh"];
            $ngaymua = $row["ngaymua"];
            $tongtien = $row["tongtien"];
            $trangthai = $row["trangthai"];
            $diachigiaohang = $row["diachigiaohang"];


            // Thay thế các giá trị vào đoạn mã HTML
            $table .= '
          
            <tr>
              <td id="ma_sp">' . $ma . '</td>
              <td>' . $emai . '</td>
              <td>' . $ngaymua . '</td>
              <td>' . $tongtien . '</td>
              <td>' . $diachigiaohang . '</td>
              <td>' . $trangthai . '</td>
              <td>
                <button style = "max-width: 80%" id="duyetdon" class="button_del_don_hang" value="' . $ma . '$' . $trangthai . '$' . $emai . '$' . $tongtien . '">Hủy đơn</i></button>
              </td>
            </tr>
          ';
          }

        } else {
          // Xử lý trường hợp không có dữ liệu
          $table .= '<tr><td colspan="12">Không có dữ liệu</td></tr>';
        }

        $table .= '</tbody></table></div>';

        // In dữ liệu sản phẩm ra màn hình
        echo $table;

        // Đóng kết nối đến cơ sở dữ liệu
        $conn->close();
        ?>

        <script>
          $(document).ready(function () {
            $('.button_del_don_hang').each(function () {
              var chuoi = $(this).val();
              var mang = chuoi.split("$");

              var id = mang[0];
              var trangthai = mang[1];
              var email = mang[2];
              var tongtien = mang[3];

              // Kiểm tra nếu trạng thái đã duyệt thì thực hiện thay đổi màu nền và nội dung
              if (trangthai !== 'Chưa duyệt') {
                $(this).css("background-color", 'green');
                $(this).html("Đã giao");
                $(this).prop("disabled", true);
                $(".element").off("mouseenter mouseleave");
              }

            });


          });

          $(document).ready(function () {
            // Gắn sự kiện click cho các button
            $(document).on("click", ".button_del_don_hang", function () {
              var button = $(this);
              var ma = button.closest("tr").find("#ma_sp").text();
              $.ajax({
                type: "POST",
                url: "./php/xoa_don_hang.php",
                data: {ma: ma},
                success:function(data){
                  alert(data)
                  location.reload()
                }
              })
            });
          });
        </script>


      </div>
    </div>
  </div>


  </div>
</body>

</html>