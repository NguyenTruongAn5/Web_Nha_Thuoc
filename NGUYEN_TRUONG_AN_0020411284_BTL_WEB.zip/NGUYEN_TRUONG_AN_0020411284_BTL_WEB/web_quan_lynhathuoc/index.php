<!-- Cập nhật số lượng truy cập  -->
<?php
// Kết nối đến cơ sở dữ liệu 
include "./php/connect.php";

// Lấy số lượt truy cập hiện tại
$sql = "SELECT so_luot FROM luot_truy_cap WHERE id = 1";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$so_luot = $row["so_luot"];

// Tăng số lượt truy cập
$so_luot++;

// Cập nhật số lượt truy cập vào cơ sở dữ liệu
$sql = "UPDATE luot_truy_cap SET so_luot = $so_luot WHERE id = 1";
mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js"></script>

  <link rel="stylesheet" href="./font/fontawesome-free-6.3.0-web/css/all.min.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="./css/reset.css">
  <link rel="stylesheet" href="./css/index.css">
  <!-- Các tài nguyên SweetAlert2 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
  <!-- <script src="./js/dang_nhap.js"></script> -->
  <title>TRANG CHỦ</title>



</head>

<body id="page_admin">


  <!-- Login -->
  <div id="dangki"></div>
  <div id="content" style="display: none;">
    <div class="container">
      <form id="login-form">
        <h2>
          Đăng nhập
          <button class="icon_close" id="an">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </h2>
        <hr>
        <div class="form-group">
          <img src="./img/logoxanh.png" alt="ảnh logo" width="16%" height="32%">
          <h3>Nhập vào tài khoản gmail</h3>
          <input style="margin-bottom: 2%;" type="tel" id="taikhoan" name="phone"
            placeholder="Nhập số điện thoại của bạn" required>
          <h3>Mật khẩu</h3>
          <input type="password" id="pass" name="phone" placeholder="Nhập mật khẩu" required>
          <a style="margin-top: 100px;position: relative;top: 80px;left: 36%;" href="./doi_mat_khau.php">Bạn quên mật
            khẩu?</a>
        </div>

        <button id="dangnhap" class="button_login" type="submit">Đăng nhập</button>
        <!-- <a class="form_a" href="#">Quên mật khẩu?</a> -->
      </form>
    </div>
  </div>

  <!-- Đăng kí -->
  <div id="hien_dangki" style="display: none">
    <div class="container">
      <form id="signup-form" style="height: 76%;">
        <h2>
          Đăng kí
          <button class="icon_close" id="an_dangki">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </h2>
        <hr>
        <div class="form-group">
          <h3>Họ và tên</h3>
          <input style="margin-bottom: 1%;" type="tel" id="name_dangki" placeholder="Họ và tên" required>
          <h3>Số điện thoại</h3>
          <input style="margin-bottom: 1%;" type="tel" id="phone_dangki" placeholder="Nhập số điện thoại của bạn"
            required>
          <h3>Email</h3>
          <input style="margin-bottom: 1%;" type="tel" id="email_dangki" placeholder="Nhập email của bạn" required>
          <h3>Mật khẩu phải đủ 8 kí tự bao gồm 1 chữ viết hoa và kí tự đặc biệt</h3>
          <input style="margin-bottom: 1%;" type="password" id="pass_dangki" placeholder="Nhập mật khẩu" required>
          <h3>Xác nhận lại mật khẩu</h3>
          <input style="margin-bottom: 1%;" type="password" id="confirm_dangki" placeholder="Xác nhận mật khẩu"
            required>
        </div>

        <button id="btn_formdangki" class="button_login" type="submit">Đăng kí</button>
      </form>
    </div>
  </div>

  <!-- viết mã ẩn hiện và xử lý đăng nhập, đăng kí -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

  <script>
    $(document).ready(function () {
      $('#an').click(function () {
        $('#content').hide();
      });
      $('#hien').click(function () {
        $('#content').show();
      })
    });
    //Xử lý đăng nhập
    $(document).ready(function () {

      $("#dangnhap").on("click", function () {
        var acc = $.trim($("#taikhoan").val());
        var pass = $.trim($("#pass").val());

        const md5Password = CryptoJS.MD5(pass).toString();

        //Lấy dữ liệu bên file php
        var email = "";
        var password = "";
        var sdt = "";
        var ten = "";
        var admin = "";
        //Lấy dữ liệu
        $.ajax({
          type: "POST",
          url: "./php/dang_nhap.php",
          data: { acc: acc, pass: pass },
          success: function (data) {
            var obj = JSON.parse(data);
            if (obj !== "rong") {
              sdt = obj.sdt;
              email = obj.email;
              ten = obj.ten;
              password = obj.matkhau;
              admin = obj.quyen;

              //Hàm kiểm tra đăng nhập sai mật khẩu
              if (md5Password !== password) {
                alert("Mật khẩu bạn đã nhập sai! Vui lòng nhập lại!")
              }
              //Nếu mật khẩu đúng và với quyền admin thì sẽ chuyển sang trang admin
              else if (md5Password === password && admin == "admin") {
                localStorage.setItem("user", ten);
                localStorage.setItem("email", email);
                window.location.href = "admin.php";

              }
              //Nếu mật khẩu đúng và với quyền khách thì sẽ chuyển sang trang chủ
              else if (md5Password === password && admin == "khach") {
                //window.location.href = "index.php";
                localStorage.setItem("user", ten);
                localStorage.setItem("email", email);
                $("#content").hide();
                $("#ten_user").html(ten);
                $("#btn_dangxuat").show();
                $("#btn_dangki").hide();
              }

            } else if (obj === "rong") {
              // xử lý tạo ra form đăng kí
              var cf_dangki = confirm("Tài khoản chưa có bạn có muốn đăng kí tài khoản mới không?")
              if (cf_dangki) {
                $("#btn_dangki").show();
              } else {
                $("#content").hide();
              }
            }

          },
          error: function (xhr, status, error) {
            console.log("Error: " + error);
          }
        });


        //$("#content").hide();
        event.preventDefault();


      })

    })
    //xử lý nút đăng xuất
    $(document).ready(function () {
      $("#btn_dangxuat").on("click", function () {
        window.location.href = "index.php";
      })
    })

    // // xử lý nút đơn hàng
    // $(document).ready(function () {
    //   $("#don_hang").on("click", function () {
    //     var acc = localStorage.getItem("email") // Thay đổi giá trị email tương ứng

    //     $.ajax({
    //       type: "POST",
    //       url: "./php/don_hang_khach_hang.php",
    //       data: { email: acc }, // Thay đổi tên biến acc tương ứng
    //       success: function (data) {
    //         alert(acc);
    //       }
    //     });

    //   });
    // });


    //xử lý ẩn hiện đăng kí
    $(document).ready(function () {
      $("#btn_dangki").on("click", function () {
        $("#hien_dangki").show();
      })
      $("#an_dangki").on("click", function () {
        $("#hien_dangki").hide();
      })
    })
    var kq = '';
    //Xứ lý đăng kí
    $(document).ready(function () {
      $("#btn_formdangki").on("click", function (event) {
        var email = $.trim($("#email_dangki").val());
        var phone = $.trim($("#phone_dangki").val());
        var name = $.trim($("#name_dangki").val());
        var pass = $.trim($("#pass_dangki").val());
        var confirm = $.trim($("#confirm_dangki").val());

        // Kiểm tra tài khoản và mật khẩu nếu khớp hết sẽ truyền qua server để xử lý
        if ((isEmail(email) || isPhoneNumber(phone)) && isStrongPassword(pass) && pass === confirm) {
          // Truyền dữ liệu
          $.ajax({
            type: "POST",
            url: "./php/xu_ly_dang_ki.php",
            data: { email: email, phone: phone, name: name, pass: pass },
            success: function (data) {
              alert(email + " " + data);
            },
            error: function (xhr, status, error) {
              console.log(xhr.responseText);
            }
          });
        } else {
          if (!(isEmail(email) || isPhoneNumber(phone))) {
            alert("Email hoặc số điện thoại không hợp lệ. Vui lòng nhập lại!");
          } else if (!isStrongPassword(pass)) {
            alert("Mật khẩu không đủ mạnh. Vui lòng nhập lại!");
          } else if (pass !== confirm) {
            alert("Xác nhận mật khẩu không khớp. Vui lòng nhập lại!");
          }
          event.preventDefault();
        }
      });

      //Hàm kiểm tài khoản có phải là gmail
      function isEmail(str) {
        const regex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
        return regex.test(str);
      }
      //Hàm kiểm tra tài khoản là số điện thoại
      function isPhoneNumber(str) {
        const regex = /^(\+?\d{1,3}[- ]?)?\d{10}$/;
        return regex.test(str);
      }
      //Kiểm tra mật khẩu phải đủ 8 kí tự có 1 kí tự đặc biệt và 1 chữ hoa
      function isStrongPassword(password) {
        const regex = /^(?=.*[A-Z])(?=.*\W).{8,}$/;
        return regex.test(password);
      }
    });



  </script>
  <!-- Beging Header -->
  <header class="header">
    <div class="header-logo">
      <a href="">
        <img src="./img/logotrang.png" alt="Ảnh LoGo" class="logo-img" width="36%" height="36%">
      </a>
    </div>
    <div class="header-main">
      <ul>
        <li class="header-main-content">
          <button id="hien" class="button_history">
            <span id="ten_user">Đăng nhập</span>
          </button>
        </li>

        <li id="btn_dangxuat" class="header-main-content" style="display: none">
          <button class="button_history">
            <span id="ten_user">Đăng xuất</span>
          </button>
        </li>

        <li id="btn_dangki" class="header-main-content">
          <button class="button_history">
            <span id="ten_user">Đăng kí</span>
          </button>
        </li>

        <li class="header-main-content"><a href="./giohang.php">
            <i class="fa-solid fa-cart-shopping"></i>
            <div id="cart-quantity" class="header-main-bell">0</div>
            Giỏ hàng/ <a href="./don_hang_kh.php?email=" id="don_hang">Đơn hàng</a>
          </a></li>
      </ul>
    </div>
    <script>
      // Lấy giá trị email từ localStorage
      var email = localStorage.getItem("email");

      // Kiểm tra xem email có tồn tại trong localStorage hay không
      if (email) {
        // Gán giá trị email vào href của thẻ a
        var donHangLink = document.getElementById("don_hang");
        donHangLink.href += encodeURIComponent(email);
      }
    </script>

  </header>

  <!-- Xử lý thông báo giỏ hàng -->
  <script>
    var storedProducts = localStorage.getItem("products");
    var products = JSON.parse(storedProducts);
    var numberOfProducts = 0;

    if (Array.isArray(products)) {
      numberOfProducts = products.length;
    }
    // Gán giá trị của numberOfProducts vào phần tử HTML
    var cartQuantityElement = document.getElementById("cart-quantity");
    cartQuantityElement.textContent = numberOfProducts.toString();
  </script>
  <nav class="navbar">
    <ul>
      <li><a href="./sanpham.php?search=thuoc_load">Thuốc</a></li>
      <li><a href="./sanpham.php?search=thuoc_load">Thực phẩm chức năng</a></li>
      <li><a href="./sanpham.php?search=thuoc_load">Thiết bị dụng cụ y tế</a></li>
      <li><a href="./sanpham.php?search=thuoc_load">Mỹ phẩm</a></li>
      <!-- <li>
        <form>
          <input type="text" placeholder="Tìm kiếm">
          <button type="submit"><i class="fas fa-search"></i></button>
        </form>
      </li> -->
    </ul>
  </nav>

  <!-- End Header -->



  <!--Beging Slider -->
  <div class="slider">
    <ul class="slides">
      <li><img src="./baner/banner1.jpg" width="100%" height="80%"></li>
      <li><img src="./baner/banner_tpcn.png" width="100%" height="80%"></li>
      <li><img src="./baner/banner_thuoc.png" width="100%" height="80%"></li>
    </ul>
    <div class="controls">
      <span class="prev">&lt;</span>
      <span class="next">&gt;</span>
    </div>
  </div>
  <script>
    $(function () {
      // Lấy các phần tử cần sử dụng
      var slides = $('.slides li');
      var controls = $('.controls span');
      var currentSlide = 0;

      // Hiển thị slide đầu tiên
      $(slides[currentSlide]).addClass('active');

      // Hàm chuyển đổi slide
      function changeSlide() {
        // Ẩn slide hiện tại
        $(slides[currentSlide]).removeClass('active');
        // Tính chỉ số slide tiếp theo
        currentSlide = (currentSlide + 1) % slides.length;
        // Hiển thị slide tiếp theo
        $(slides[currentSlide]).addClass('active');
      }

      // Tự động chuyển đổi slide sau mỗi 5 giây
      var interval = setInterval(changeSlide, 5000);

      // Xử lý sự kiện khi click vào nút điều khiển
      controls.on('click', function () {
        // Dừng auto slide
        clearInterval(interval);
        // Lấy chỉ số của nút được click
        var index = controls.index(this);
        // Ẩn slide hiện tại
        $(slides[currentSlide]).removeClass('active');
        // Hiển thị slide tương ứng với nút được click
        currentSlide = index;
        $(slides[currentSlide]).addClass('active');
        // Bắt đầu auto slide lại

        interval = setInterval(changeSlide, 5000);
      })
    });

  </script>
  <!-- End Slider -->

  <!-- beging product -->
  <div class="product-bg">
    <div class="product-tilte">Sản Phẩm Nổi Bậc Hôm Nay</div>
    <!-- code php đổ sản phẩm lên -->
    <?php

    // Thông tin kết nối đến cơ sở dữ liệu
    include "./php/connect.php";

    // Lấy dữ liệu từ cơ sở dữ liệu
    $sql = "SELECT ma_sp, ten_sp, hinh, giamgia, gia_sp, dong_goi FROM san_pham order by so_luong asc limit 5"; // giả sử id sản phẩm là 1
    $result = mysqli_query($conn, $sql);


    // Kiểm tra kết quả truy vấn
    if (mysqli_num_rows($result) > 0) {
      // Lấy các giá trị cần thiết từ hàng dữ liệu đầu tiên (giả sử chỉ có 1 sản phẩm)
      while ($row = mysqli_fetch_assoc($result)) {
        $image = $row["hinh"];
        $price = $row["gia_sp"];
        $discount = $row["giamgia"];
        $name = $row["ten_sp"];
        $dong_goi = $row["dong_goi"];
        $ma_sp = $row["ma_sp"];

        // Tính toán giá sau khi giảm giá
        $discounted_price = $price * (1 - $discount / 100);

        // Thay thế các giá trị vào đoạn mã HTML
        $html = '<div class="product-card">
                  <div class="discount-percent">-' . $discount . '%</div>
                  
                    <img src="' . $image . '" alt="' . $name . '" width="100%" height="100%">
                  
                  <div class="product-count">' . $dong_goi . '</div>
                  <h3 class="product-name">' . $name . '</h3>
                  <div class="product-price">' . number_format($discounted_price, 0, '.', '.') . 'đ/
                    <span>' . number_format($price, 0, '.', '.') . 'đ</span>
                  </div>
                  <a target="_blank" href="chitietsp.php?masp=' . $ma_sp . '" style="text-decoration: none;">
                  <button class="buy-now-button">Mua Ngay</button>
                  </a>
                </div>';
        echo $html;
      }

    } else {
      echo "Không có dữ liệu";
    }

    // Đóng kết nối đến cơ sở dữ liệu
    $conn->close();

    ?>

  </div>
  <!-- End product today -->

  <!-- Beging product saler -->
  <div class="product-tilte-sale">Sản Phẩm Bán Chạy Nhất</div>
  <?php
  // Thông tin kết nối đến cơ sở dữ liệu
  include "./php/connect.php";
  // Lấy dữ liệu từ cơ sở dữ liệu
  $sql = "SELECT ma_sp, ten_sp, gia_sp, giamgia, hinh, dong_goi FROM san_pham order by luot_mua desc limit 5 "; // giả sử id sản phẩm là 1
  $result = mysqli_query($conn, $sql);
  // Kiểm tra kết quả truy vấn
  if (mysqli_num_rows($result) > 0) {
    // Lấy các giá trị cần thiết từ hàng dữ liệu đầu tiên 
    while ($row = mysqli_fetch_assoc($result)) {
      $image = $row["hinh"];
      $price = $row["gia_sp"];
      $discount = $row["giamgia"];
      $name = $row["ten_sp"];
      $dong_goi = $row["dong_goi"];
      $ma_sp = $row["ma_sp"];

      // Tính toán giá sau khi giảm giá
      $discounted_price = $price * (1 - $discount / 100);

      // Thay thế các giá trị vào đoạn mã HTML
      $html = '<div class="product-card">
                  <div class="discount-percent">-' . $discount . '%</div>
                    <img src="' . $image . '" alt="' . $name . '" width="220" height="120">
                  <div class="product-count">' . $dong_goi . '</div>
                  <h3 class="product-name">' . $name . '</h3>
                  <div class="product-price">' . number_format($discounted_price, 0, '.', '.') . 'đ/
                    <span>' . number_format($price, 0, '.', '.') . 'đ</span>
                  </div>
                  <a target="_blank" href="chitietsp.php?masp=' . $ma_sp . '" style="text-decoration: none;">
                  <button class="buy-now-button">Mua Ngay</button>
                  </a>
                </div>';
      echo $html;
    }

  } else {
    echo "Không có dữ liệu";
  }
  $conn->close();

  ?>
  <!-- End product sale -->

  <!-- Beging product medicine -->
  <img src="./baner/banner_thuoc.png" alt="Banner thực phẩm chức năng" width="100%" height="100%">
  <script>
    $(document).ready(function () {
      $('#bt_ho').click(function () {
        $("#product-list").load("./php/lay_thuoc_ho.php");
        $("#bt_ho").css({
          "background-color": "#072D94",
          "color": "#fff"
        });
        $("#bt_hong").css({
          "background-color": "#fff",
          "color": "#072D94"
        });
        $("#bt_sot").css({
          "background-color": "#fff",
          "color": "#072D94"
        });
      });

    });
    $(document).ready(function () {
      $('#bt_sot').click(function () {
        $("#product-list").load("./php/lay_thuoc_sot.php");
        $("#bt_sot").css({
          "background-color": "#072D94",
          "color": "#fff"
        });
        $("#bt_ho").css({
          "background-color": "#fff",
          "color": "#072D94"
        });
        $("#bt_hong").css({
          "background-color": "#fff",
          "color": "#072D94"
        });
      });
    });
    $(document).ready(function () {
      $('#bt_hong').click(function () {
        $("#product-list").load("./php/lay_thuoc_hong.php");
        $("#bt_hong").css({
          "background-color": "#072D94",
          "color": "#fff"
        });
        $("#bt_ho").css({
          "background-color": "#fff",
          "color": "#072D94"
        });
        $("#bt_sot").css({
          "background-color": "#fff",
          "color": "#072D94"
        });
      });

    });
  </script>

  <div class="banner_button">
    <button id="bt_sot" class="button_product">Giảm đau, Hạ sốt</button>
    <button id="bt_ho" class="button_product">Thuốc ho</button>
    <button id="bt_hong" class="button_product">Tai mũi họng</button>
  </div>
  <div id="product-list">
    <?php
    include "./php/lay_thuoc_sot.php";
    ?>
  </div>
  <a href="./sanpham.php" class="d-flex justify-content-center align-items-center"
    style="font-size: 1rem; text-decoration: none;">
    Xem thêm
  </a>
  <!-- End product medicine -->
  <!-- beging functional foood -->
  <div class="menu_product">
    <div class="">
      <img src="./baner/banner_tpcn.png" alt="Banner thực phẩm chức năng" width="100%" height="100%">
    </div>
    <script>
      $(document).ready(function () {
        $('#bt_vitamin').click(function () {
          $("#product-list-tpcn").load("./php/lay_vitamin.php");
          $("#bt_vitamin").css({
            "background-color": "#072D94",
            "color": "#fff"
          });
          $("#bt_bo_gan").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
          $("#bt_bo_nao").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
        });

      });
      $(document).ready(function () {
        $('#bt_bo_gan').click(function () {
          $("#product-list-tpcn").load("./php/lay_bo_gan.php");
          $("#bt_bo_gan").css({
            "background-color": "#072D94",
            "color": "#fff"
          });
          $("#bt_vitamin").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
          $("#bt_bo_nao").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
        });
      });
      $(document).ready(function () {
        $('#bt_bo_nao').click(function () {
          $("#product-list-tpcn").load("./php/lay_bo_nao.php");
          $("#bt_bo_nao").css({
            "background-color": "#072D94",
            "color": "#fff"
          });
          $("#bt_bo_gan").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
          $("#bt_vitamin").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
        });

      });
    </script>

    <div class="banner_button">
      <button id="bt_vitamin" class="button_product">Vitamin</button>
      <button id="bt_bo_gan" class="button_product">Bổ gan, Thanh nhiệt</button>
      <button id="bt_bo_nao" class="button_product">Bổ não</button>
    </div>
    <div id="product-list-tpcn">
      <?php
      include "./php/lay_vitamin.php";
      ?>
    </div>
  </div>
  <a href="./sanpham.php" class="d-flex justify-content-center align-items-center"
    style="font-size: 1rem; text-decoration: none;">
    Xem thêm
  </a>
  <!-- end functional food -->
  <!-- medical equipment -->
  <div class="menu_product">
    <div class="">
      <img src="./baner/thietBiYTe.png" alt="Banner thực phẩm chức năng" width="100%" height="100%">
    </div>
    <script>
      $(document).ready(function () {
        $('#bt_nhiet_ke').click(function () {
          $("#product-list-tbyt").load("./php/lay_nhiet_ke.php");
          $("#bt_nhiet_ke").css({
            "background-color": "#072D94",
            "color": "#fff"
          });
          $("#bt_thu-duong").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
          $("#bt_huyet_ap").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
        });

      });
      $(document).ready(function () {
        $('#bt_thu_duong').click(function () {
          $("#product-list-tbyt").load("./php/lay_thu_duong.php");
          $("#bt_thu_duong").css({
            "background-color": "#072D94",
            "color": "#fff"
          });
          $("#bt_nhiet_ke").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
          $("#bt_huyet_ap").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
        });
      });
      $(document).ready(function () {
        $('#bt_huyet_ap').click(function () {
          $("#product-list-tbyt").load("./php/lay_huyet_ap.php");
          $("#bt_huyet_ap").css({
            "background-color": "#072D94",
            "color": "#fff"
          });
          $("#bt_thu_duong").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
          $("#bt_nhiet_ke").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
        });

      });
    </script>

    <div class="banner_button">
      <button id="bt_nhiet_ke" class="button_product">Nhiệt kế</button>
      <button id="bt_thu_duong" class="button_product">Que thử đường</button>
      <button id="bt_huyet_ap" class="button_product">Máy đo huyết áp</button>
    </div>
    <div id="product-list-tbyt">
      <?php
      include "./php/lay_nhiet_ke.php";
      ?>
    </div>
  </div>
  <a href="./sanpham.php" class="d-flex justify-content-center align-items-center"
    style="font-size: 1rem; text-decoration: none;">
    Xem thêm
  </a>
  <!-- end medical equipment -->
  <!-- cosmetics -->
  <div class="menu_product">
    <div class="">
      <img src="./baner/mypham.png" alt="Banner thực phẩm chức năng" width="100%" height="100%">
    </div>
    <script>
      $(document).ready(function () {
        $('#bt_duong_da').click(function () {
          $("#product-list-mp").load("./php/lay_duong_da.php");
          $("#bt_duong_da").css({
            "background-color": "#072D94",
            "color": "#fff"
          });
          $("#bt_chong_nang").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
          $("#bt_rua_mat").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
        });

      });
      $(document).ready(function () {
        $('#bt_chong_nang').click(function () {
          $("#product-list-mp").load("./php/lay_chong_nang.php");
          $("#bt_chong_nang").css({
            "background-color": "#072D94",
            "color": "#fff"
          });
          $("#bt_rua_mat").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
          $("#bt_duong_da").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
        });
      });
      $(document).ready(function () {
        $('#bt_rua_mat').click(function () {
          $("#product-list-mp").load("./php/lay_rua_mat.php");
          $("#bt_rua_mat").css({
            "background-color": "#072D94",
            "color": "#fff"
          });
          $("#bt_chong_nang").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
          $("#bt_duong_da").css({
            "background-color": "#fff",
            "color": "#072D94"
          });
        });

      });
    </script>

    <div class="banner_button">
      <button id="bt_duong_da" class="button_product">Dưỡng da</button>
      <button id="bt_chong_nang" class="button_product">Xịt chống nắng</button>
      <button id="bt_rua_mat" class="button_product">Sửa rửa mặt</button>
    </div>
    <div id="product-list-mp">
      <?php
      include "./php/lay_duong_da.php";
      ?>
    </div>
  </div>
  <a href="./sanpham.php" class="d-flex justify-content-center align-items-center"
    style="font-size: 1rem; text-decoration: none;">
    Xem thêm
  </a>
  <!-- end cosmetics -->

  <!-- Beging Footer -->
  <footer>
    <div class="row">
      <div class="col-md-3">
        <h4 class="footer_title">Thông tin liên hệ</h4>
        <p>Tâm An - Nhà thuốc vì sức khỏe mọi người</p>
        <hr>
        <p><i class="fas fa-map-marker-alt"></i>Địa chỉ: Khóm 4, Phường 6 Tp.Cao Lãnh, Đồng Tháp</p>
        <p><i class="fas fa-phone"></i>Số điện thoại: 0564056521</p>
        <p><i class="fas fa-envelope"></i>Email: kaicapro@gmail.com</p>
      </div>
      <div class="col-md-3">
        <h4 class="footer_title">Hỗ trợ khách hàng</h4>
        <ul>
          <li><a href="./gioithieu.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Giới thiệu
              <hr>
            </a></li>
          <li> <a href="./chinhsachdoitra.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Chính sách đổi trả
              <hr>
            </a></li>
          <li> <a href="./chinhsachbaomat.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Chính sách bảo mật
              <hr>
            </a></li>
          <li> <a href="./chinhsachgiaohang.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Chính sách giao hàng
              <hr>
            </a></li>
        </ul>
      </div>
      <div class="col-md-3">
        <h4 class="footer_title">Tìm kiếm nhanh</h4>
        <ul>
          <li><button id="chuyentrang_tpcn">Thực phẩm chức năng</button></li>
          <li><button id="chuyentrang_tbyt">Dụng cụ y tế</button></li>
          <li>
            <img src="./img/bct.png" alt="Ảnh Bộ Công Thương" width="100px" height="10%" style="margin: -16px 0;">
            <p>GCN ĐĐKKDT SỐ 0672/HCM-DDKKDDD,
              22/07/2014, SỞ Y TẾ TP.HCM</p>
          </li>
        </ul>
      </div>
      <div class="col-md-3">
        <h4 class="footer_title">Ưu đãi hấp dẫn</h4>
        <ul>
          <li>Mỗi tháng chúng tôi đều có những đợt giảm giá dịch vụ và sản phẩm nhằm tri ân khách hàng. Để có thể cập
            nhật kịp thời những đợt giảm giá này, vui lòng nhập số điện thoại của bạn vào ô dưới đây.</li>
          <li><input id="emai_tv" type="text" placeholder="Để lại email để được tư vấn"><i id="email_tuvan"
              class="fas fa-paper-plane"></i></li>
        </ul>
      </div>
    </div>
    <hr>
    <p class="copy_right">Copyrights © 2023 by Truong An. Powered by Tâm An</p>
  </footer>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
      $("#email_tuvan").on("click", function () {
        var email_tv = $("#emai_tv").val(); // Lấy giá trị từ phần tử input có id "emai_tv"
        var trimmedEmail = email_tv.trim();
        $.ajax({
          type: "POST",
          url: "./sendmail_tuvan.php",
          data: { email: trimmedEmail },
          success: function (data) {
            Swal.fire({
              icon: 'success',
              title: 'Thông báo',
              text: 'Thông tin tư vấn đã gửi về mail của bạn. Vui lòng xem email!',
              showConfirmButton: false,
              timer: 0 // Tắt sau 2 giây
            });
          }
        })
      })

      // nhấn nút chuyển trang
      $("#chuyentrang_tpcn").on("click", function () {
        window.location.href = "./sanpham.php";
      })
      $("#chuyentrang_tbyt").on("click", function () {
        window.location.href = "./sanpham.php";
      })
    })
  </script>
  <!-- End Footer -->
</body>

</html>