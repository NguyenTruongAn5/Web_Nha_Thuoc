<?php

include 'connect.php';

$new_id = $_POST['id']; // "sanpham01"
$trangthai = "Đã duyệt";

echo $new_id;
$sql = "UPDATE `hoadon` 
SET `trangthai` = '$trangthai'  
WHERE `ma_hoadon` = '$new_id'";



$query = mysqli_query($conn, $sql);
if ($query) {
    echo "Cập nhật thành công";
} else {
    echo "Cập nhật thất bại";
}

?>