<?php 
include 'connect.php';
$id = $_POST['id'];
$sql = "DELETE FROM san_pham WHERE `san_pham`.`ma_sp` = '$id'";
$query = mysqli_query($conn, $sql);
if ($query){
    echo "Xóa thành công!";
}else{
    echo "Xóa thất bại";
}
?>