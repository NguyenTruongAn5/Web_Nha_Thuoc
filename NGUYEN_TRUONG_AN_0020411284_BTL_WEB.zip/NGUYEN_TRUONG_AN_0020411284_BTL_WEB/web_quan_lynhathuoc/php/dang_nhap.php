<?php
include 'connect.php';
$acc = $_POST['acc'];
$pass = $_POST['pass'];
$sql = "SELECT sdt, ten_kh, matkhau, quyen, email FROM khachhang WHERE sdt = '$acc' OR email = '$acc'";
$query = mysqli_query($conn, $sql);

$data = array(); // Khởi tạo mảng $data

// Duyệt qua từng dòng dữ liệu và thêm vào mảng
if ($query) {
    while ($row = mysqli_fetch_assoc($query)) {
        $data['sdt'] = $row['sdt'];
        $data['ten'] = $row['ten_kh'];
        $data['matkhau'] = $row['matkhau'];
        $data['quyen'] = $row['quyen'];
        $data['email'] = $row['email'];
    }
    // Trả về dữ liệu dưới dạng JSON
    echo json_encode($data);
} else {
    // Trả về chuỗi "rong" dưới dạng JSON
    $data['rong'] = "rong";
    echo json_encode($data);
}
?>
