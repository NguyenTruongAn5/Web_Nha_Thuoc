<!DOCTYPE html>
<html>

<head>
    <title>Quên mật khẩu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="./font/fontawesome-free-6.3.0-web/css/all.min.css">
    <!-- Các tài nguyên SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
    <!-- md5 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/blueimp-md5/2.18.0/js/md5.min.js"></script>

    <style>
        /* login */

        body {
            background-color: #ccc;
        }

        .container {
            position: fixed;
            top: 0;
            left: 0;
            right: 0px;
            width: 100%;
            height: 80%;
            max-height: 640px;
            z-index: 9999;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow-x: hidden;
            overflow-y: auto;

        }


        .container>form {
            /* CSS cho form đăng nhập */
            z-index: 10000;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            width: 32%;
            height: 72%;
            border-radius: 12px;
        }

        .icon_close {
            margin-left: 70%;
            border: none;
            background-color: #fff;
        }

        .container>form>h2 {
            display: flex;
            justify-content: center;
            margin-top: 4%;
            font-size: 0.8rem;
            color: var(--primary-color);
            font-weight: bold;
        }

        .form-group>h3 {
            font-size: .6rem;
            text-align: left;
            margin-left: 6%;
        }

        .form-group>a {
            font-size: .8rem;
            text-decoration: none;
        }

        .form-group>a>img {
            display: flex;
            margin: auto;
        }

        .form-group>input {
            width: 90%;
            height: 36px;
            display: flex;
            margin: auto;
            border: .5px solid #ccc;
            border-radius: 8px;
            font-size: .8rem;
            padding-left: 2%;

        }

        .form-group>input:focus {
            outline: solid var(--primary-color) 1px;
        }

        .btn_login {
            background-color: blue;
            border: none;
            width: 40%;
            height: 12%;
            color: #fff;
            border-radius: 16px;
            position: relative;
            left: 50%;
            top: 20px;
            transform: translate(-50%, -50%);
            margin-top: 3%;
            font-size: 1rem;
        }

        /* end login */
    </style>

</head>

<body>
    <!-- Thêm thư viện jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Login -->
    <div class="container">
        <form id="login-form">
            <h2>Đổi mật khẩu</h2>
            <hr>
            <div class="form-group">
                <a href="./index.php"><img src="./img/logoxanh.png" alt="ảnh logo" width="16%" height="32%"></a>
                <h3>Nhập vào mật khẩu mới</h3>
                <input style="margin-bottom: 2%;" name="password" type="password" id="password"
                    placeholder="Nhập vào mật khẩu mới" required>
                <h3>Xác nhận mật khẩu</h3>
                <input style="margin-bottom: 2%;" name="confirm" type="password" id="confirm"
                    placeholder="Xác nhận mật khẩu" required>
                <button value="nutgui" name="guiyeucau" id="xacnhan" class="btn_login">Xác nhận</button>
            </div>
        </form>
    </div>

    <script>
        $(document).ready(function () {
            $("#xacnhan").on("click", function () {
                var password = $("#password").val();
                var confirm = $("#confirm").val();

                // Gọi hàm kiểm tra mật khẩu
                var isValidPassword = checkPassword(password);

                // Kiểm tra kết quả trả về từ hàm
                if (isValidPassword) {
                    if (password === confirm) {
                        alert("Đã đổi mật khẩu thành công");
                        var email = localStorage.getItem('email_mk');
                        
                        $.ajax({
                            type: "POST",
                            url: "./update_mat_khau.php",
                            data: { password: password, email: email },
                            success: function (data) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Thông báo',
                                    text: 'Thông tin tư vấn đã gửi về mail của bạn. Vui lòng xem email!',
                                    showConfirmButton: false,
                                }).then(() => {
                                    window.location.replace("./index.php"); // Chuyển về trang index
                                });
                            }
                        });
                    } else {
                        alert("Mật khẩu và xác nhận không khớp nhau!");
                    }
                } else {
                    // Mật khẩu không hợp lệ
                    alert("Mật khẩu không hợp lệ. Mật khẩu phải có ít nhất 8 ký tự, 1 ký tự đặc biệt và 1 chữ hoa.");
                }
            });

            // Hàm kiểm tra mật khẩu
            function checkPassword(password) {
                if (password.length >= 8 && /[A-Z]/.test(password) && /[^A-Za-z0-9]/.test(password)) {
                    // Mật khẩu hợp lệ
                    return true;
                } else {
                    // Mật khẩu không hợp lệ
                    return false;
                }
            }
        });
    </script>

</body>

</html>