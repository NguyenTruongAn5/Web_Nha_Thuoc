<!DOCTYPE html>
<html>

<head>
    <title>Quên mật khẩu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="./font/fontawesome-free-6.3.0-web/css/all.min.css">
    <!-- Các tài nguyên SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
    <!-- md5 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/blueimp-md5/2.18.0/js/md5.min.js"></script>

    <style>
        /* login */

        body {
            background-color: #ccc;
        }

        .container {
            position: fixed;
            top: 0;
            left: 0;
            right: 0px;
            width: 100%;
            height: 80%;
            max-height: 640px;
            z-index: 9999;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow-x: hidden;
            overflow-y: auto;

        }


        .container>form {
            /* CSS cho form đăng nhập */
            z-index: 10000;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            width: 32%;
            height: 64%;
            border-radius: 12px;
        }

        .icon_close {
            margin-left: 70%;
            border: none;
            background-color: #fff;
        }

        .container>form>h2 {
            display: flex;
            justify-content: center;
            margin-top: 4%;
            font-size: 0.8rem;
            color: var(--primary-color);
            font-weight: bold;
        }

        .form-group>h3 {
            font-size: .6rem;
            text-align: left;
            margin-left: 6%;
        }

        .form-group>a {
            font-size: .8rem;
            text-decoration: none;
        }

        .form-group>a>img {
            display: flex;
            margin: auto;
        }

        .form-group>input {
            width: 90%;
            height: 36px;
            display: flex;
            margin: auto;
            border: .5px solid #ccc;
            border-radius: 8px;
            font-size: .8rem;
            padding-left: 2%;

        }

        .form-group>input:focus {
            outline: solid var(--primary-color) 1px;
        }

        .btn_login {
            background-color: blue;
            border: none;
            width: 40%;
            height: 12%;
            color: #fff;
            border-radius: 16px;
            position: relative;
            left: 50%;
            top: 20px;
            transform: translate(-50%, -50%);
            margin-top: 3%;
            font-size: 1rem;
        }

        .countdown {
            font-size: 1rem;
            text-align: center;
            margin-top: 4px;
            color: red;
        }

        /* end login */
    </style>

</head>

<body>
    <!-- Login -->
    <div class="container">
        <form method="post" id="login-form">
            <h2>
                Đổi mật khẩu
            </h2>
            <hr>
            <div class="form-group">
                <a href="./index.php"><img src="./img/logoxanh.png" alt="ảnh logo" width="16%" height="32%"></a>
                <div class="countdown">
                    <span id="timer">40</span> giây
                </div>
                <h3>Nhập vào mã otp</h3>

                <input style="margin-bottom: 2%;" name="otp" type="otp" id="otp" placeholder="Nhập vào mã otp" required>

                <button value="nutgui" name="guiyeucau" id="xacnhan_otp" class="btn_login">Xác nhận</button>
            </div>
            <!-- <a class="form_a" href="#">Quên mật khẩu?</a> -->

        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function () {
            var countdownTime = 40;

            function countdown() {
                $("#timer").text(countdownTime);

                if (countdownTime === 0) {
                    clearInterval(timerInterval);
                    window.location.href = "./doi_mat_khau.php";
                }

                countdownTime--;
            }

            var timerInterval = setInterval(countdown, 1000);

            $("#xacnhan_otp").on("click", function () {
                var otpGetLocal = localStorage.getItem("otp");
                var otp_nhap = $("#otp").val();
                var hashedOTP_nhap = md5(otp_nhap);

                if(otpGetLocal === hashedOTP_nhap){
                    window.location.href = "./mat_khau_moi.php";
                    alert("Mã OTP hợp lệ")
                }else{
                    alert("Mã OTP không hợp lệ. Vui lòng nhập lại")
                }
            })
        });
    </script>

</body>

</html>