$(document).ready(()=>{
    $('.img-scale').attr('src', $('img').first().attr('src'))

    //Gắn sự kiện click cho toàn thẻ img
    $('img').on('click', e=>{
        $('.img-scale').attr('src', e.target.src)
    })
})
