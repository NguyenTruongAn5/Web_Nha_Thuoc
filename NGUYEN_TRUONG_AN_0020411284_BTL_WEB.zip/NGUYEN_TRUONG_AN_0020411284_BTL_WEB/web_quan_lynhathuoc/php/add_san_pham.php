<?php
include 'connect.php';

$select_ma = "SELECT * FROM san_pham ORDER BY ma_sp DESC LIMIT 1;";
$result_query = mysqli_query($conn, $select_ma);
$result_ma = mysqli_fetch_assoc($result_query);
$ma = $result_ma["ma_sp"];

echo $ma;

// Tách số cuối cùng của chuỗi
$last_number = substr($ma, -2); // "01"

// Tăng số cuối cùng lên 1
$new_number = sprintf("%02d", intval($last_number) + 1); // "02"

// Tạo mã mới
$new_id = "sanpham" . $new_number; // "sanpham02"

$tensp = $_POST['tensp'];
$giasp = $_POST['giasp'];
$giamgia = $_POST['giamgia'];
$thongtinngan = $_POST['thongtinngan'];
$thongtinchitiet = $_POST['thongtinchitiet'];
$loaisp = $_POST['loaisp'];
$cachdonggoi = $_POST['cachdonggoi'];
$soluong = $_POST['soluong'];
$hinhsp = $_POST['hinhsp'];
$luotmua = 0;

$sql = "INSERT INTO `san_pham` (`ma_sp`, `ten_sp`, `gia_sp`, `giamgia`, `hinh`, `thongtin_ngan`, `thongtinchitiet`, `loai_sp`, `dong_goi`, `so_luong`, `luot_mua`) 
VALUES ('$new_id', '$tensp', '$giasp', '$giamgia', '$hinhsp', '$thongtinngan', '$thongtinchitiet', '$loaisp', '$cachdonggoi', '$soluong', '$luotmua')";

$query = mysqli_query($conn, $sql);
if ($query) {
    echo "Thêm thành công";
} else {
    echo "Thêm thất bại";
}
?>
