<?php
if (isset($_POST['password']) && isset($_POST['email'])) {
    $password = $_POST['password'];
    $pass_md5 = md5($password);
    $email = $_POST['email'];

    include "./php/connect.php";

    $sql = "UPDATE khachhang SET matkhau = '$pass_md5' WHERE email = '$email'";

    $result = mysqli_query($conn, $sql);
}
?>
