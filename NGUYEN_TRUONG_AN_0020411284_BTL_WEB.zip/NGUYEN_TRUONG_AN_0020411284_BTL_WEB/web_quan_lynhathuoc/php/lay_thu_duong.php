<?php
  // Thông tin kết nối đến cơ sở dữ liệu
  include "connect.php";
  // Lấy dữ liệu từ cơ sở dữ liệu
  $sql = "SELECT ma_sp, ten_sp, hinh, giamgia, gia_sp, dong_goi FROM san_pham where loai_sp ='thu_duong' limit 5 "; // giả sử id sản phẩm là 1
  $result = mysqli_query($conn, $sql);
  // Kiểm tra kết quả truy vấn
  if (mysqli_num_rows($result) > 0) {
    // Lấy các giá trị cần thiết từ hàng dữ liệu đầu tiên (giả sử chỉ có 1 sản phẩm)
    while ($row = mysqli_fetch_assoc($result)) {
      $image = $row["hinh"];
      $price = $row["gia_sp"];
      $discount = $row["giamgia"];
      $name = $row["ten_sp"];
      $dong_goi = $row["dong_goi"];
      $ma_sp = $row["ma_sp"];

      // Tính toán giá sau khi giảm giá
      $discounted_price = $price * (1 - $discount / 100);

      // Thay thế các giá trị vào đoạn mã HTML
      $html = '<div class="product-card">
                  <div class="discount-percent">-' . $discount . '%</div>
                  <a href="">
                    <img src="' . $image . '" alt="' . $name . '" width="220px" height="120px">
                  </a>
                  <div class="product-count">' . $dong_goi . '</div>
                  <h3 class="product-name ellipsis">' . $name . '</h3>
                  <div class="product-price">' . number_format($discounted_price, 0, '.', '.') . 'đ/
                    <span>' . number_format($price, 0, '.', '.') . 'đ</span>
                  </div>
                  <a target="_blank" href="chitietsp.php?masp='.$ma_sp.'" style="text-decoration: none;">
                  <button class="buy-now-button">Mua Ngay</button>
                  </a>
                </div>';
      echo $html;
    }

  } else {
    echo "Không có dữ liệu";
  }

  // Đóng kết nối đến cơ sở dữ liệu
  $conn->close();

  ?>
  