<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
  <link rel="stylesheet" href="./font/fontawesome-free-6.3.0-web/css/all.min.css">
  <link rel="stylesheet" href="./css/reset.css">
  <link rel="stylesheet" href="./css/product.css">
  <!-- Các tài nguyên SweetAlert2 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
  <title>Đặt hàng</title>

  <style>
    .product-img {
      width: 100px;
    }

    td.product-name {
      font-weight: bold;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 100px;
      cursor: default;
    }

    td.product-name:hover {
      white-space: normal;
      overflow: visible;
      cursor: pointer;
    }

    .product-price {
      color: green;
    }

    .total-price {
      font-weight: bold;
      font-size: 1rem;
    }

    .center {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }

    .quantity-control {
      display: flex;
      align-items: center;
    }

    .quantity-btn-tang,
    .quantity-btn-giam {
      padding: 4px 12px;
      outline: none;
      border: 0px;
      font-size: 1rem;
      border-radius: 4px;
      text-align: center;
      color: #fff;
    }

    .quantity-btn-tang {
      background-color: var(--primary-color);
    }

    .quantity-btn-giam {
      background-color: gray;
    }

    .checkout-button {
      margin-top: 20px;
      width: 100%;
      height: 20%;
    }

    .soluong {
      font-size: 1rem;
      margin: 0 8px;
    }
  </style>
</head>

<body>
  <!-- Beging Header -->
  <header class="header">
    <div class="header-logo">
      <a href="./index.php">
        <img src="./img/logotrang.png" alt="Ảnh LoGo" class="logo-img" width="36%" height="36%">
      </a>
    </div>
    <div class="header-main">
      <ul>
        <li class="header-main-content">
          <button id="hien" class="button_history">
            <span id="ten_user">Đăng nhập</span>
          </button>
        </li>

        <!-- <li id="btn_dangxuat" class="header-main-content" style="display: none">
          <button class="button_history">
            <span id="ten_user">Đăng xuất</span>
          </button>
        </li>

        <li id="btn_dangki" class="header-main-content">
          <button class="button_history">
            <span id="ten_user">Đăng kí</span>
          </button>
        </li> -->

        <li class="header-main-content"><a href="./giohang.php">
            <i class="fa-solid fa-cart-shopping"></i>
            <div id="cart-quantity" class="header-main-bell">2</div>
            Giỏ hàng
          </a></li>
      </ul>
    </div>
    <!-- Xử lý thông báo giỏ hàng -->
    <script>

      var storedProducts = localStorage.getItem("products");
      var products = JSON.parse(storedProducts);
      var numberOfProducts = products.length;

      // Gán giá trị của numberOfProducts vào phần tử HTML
      var cartQuantityElement = document.getElementById("cart-quantity");
      cartQuantityElement.textContent = numberOfProducts.toString();
    </script>
  </header>

  <nav class="navbar">
    <ul>
      <li><a href="./sanpham.php?search=thuoc_load">Thuốc</a></li>
      <li><a href="./sanpham.php?search=thuoc_load">Thực phẩm chức năng</a></li>
      <li><a href="./sanpham.php?search=thuoc_load">Thiết bị dụng cụ y tế</a></li>
      <li><a href="./sanpham.php?search=thuoc_load">Mỹ phẩm</a></li>
      <!-- <li>
          <form>
            <input type="text" placeholder="Tìm kiếm">
            <button type="submit"><i class="fas fa-search"></i></button>
          </form>
        </li> -->
    </ul>
  </nav>
  <!-- End Header -->

  <!-- Beging container -->
  <div class="container">

    <!-- Thông tin đơn hàng -->
    <div class="row">
      <h2>Thông tin đơn hàng</h2>
      <div class="col-md-4">
        <table class="table">
          <!-- Tiêu đề bảng -->
          <thead id="tt_giohang">
            <tr>
              <th style="font-size: .8rem;">Hình ảnh</th>
              <th style="font-size: .8rem;">Tên thuốc</th>
              <th style="font-size: .8rem;">Giá</th>
              <th style="font-size: .8rem;">Số lượng</th>
              <th style="font-size: .8rem;">Tổng tiền</th>
              <th style="font-size: .8rem;"></th>
            </tr>
          </thead>
          <tbody id="cart-items">
            <!-- Các hàng sản phẩm sẽ được thêm vào đây -->
          </tbody>
          <tfoot id="ft_giohang">
            <tr>
              <td style="font-size: 1rem;" colspan="4" class="text-right">Tổng cộng:</td>
              <td style="font-size: 1rem;" id="total-price" class="total-price">$0</td>
              <td style="font-size: 1rem;"></td>
            </tr>
          </tfoot>
        </table>
      </div>

    </div>

    <!-- Xứ lý js cho load sản phẩm -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
      // Xử lý nút mua ngay
      $(document).ready(function () {
        // Hiện tên
        var ten = localStorage.getItem("user");
        var email = localStorage.getItem("email");
        $("#ten_user").html(ten);

        // Gán giá trị vào ô input và không cho người dùng nhập vào
        $("#name").val(ten).prop("disabled", true);
        $("#email").val(email).prop("disabled", true);


        $("#muangay").on("click", function () {
          window.location.href = "./index.php";
        })
      })
      $(document).ready(function () {
        var storedProducts = localStorage.getItem("products");
        var products = JSON.parse(storedProducts);

        var cartItemsElement = $("#cart-items");
        var totalPriceElement = $("#total-price");

        var formatter = new Intl.NumberFormat("vi-VN", {
          style: "currency",
          currency: "VND",
        });

        if (products === null || products.length === 0) {
          $("#giohangrong").show();
          $("#btn_giohang").hide();
          $("#tt_giohang").hide();
          $("#ft_giohang").hide();
        } else {
          for (var i = 0; i < products.length; i++) {
            var product = products[i];
            var hinhChiTiet = product.hinhChiTiet;
            var tenSp = product.tenSp;
            var giaSp = product.giaSp;
            var giamGia = product.giamGia;
            var arrHinh = product.arrHinh;
            var soluong = 1;
            // Biến tổng cộng
            var totalPrice = 0;


            var giaSpFormatted = formatter.format(giaSp);

            var row = $("<tr></tr>");
            row.html(`
            <td><img class="product-img" src="${hinhChiTiet}"></td>
            <td style="font-size: 0.8rem; font-weight: 400;" class="product-name">${tenSp}</td>
            <td class="product-price">${giaSpFormatted}</td>
            <td>
              <div class="quantity-control">
                <button class="quantity-btn-giam">-</button>
                <span class="soluong">${soluong}</span>
                <button class="quantity-btn-tang">+</button>
              </div>
            </td>
            <td class="total-price">${giaSpFormatted}</td>
            <td><button class="btn btn-sm btn-danger"><i class="fa-solid fa-trash"></i></button></td>
          `);

            cartItemsElement.append(row);
          }
        }

        $(".quantity-btn-tang").on("click", function () {
          var quantityElement = $(this).siblings(".soluong");
          var currentQuantity = parseInt(quantityElement.text());
          var newQuantity = currentQuantity + 1;
          quantityElement.text(newQuantity);

          var productPriceElement = $(this).closest("tr").find(".product-price");
          var productPrice = parseFloat(productPriceElement.text().replace(/\D/g, ""));
          var newTotalPrice = productPrice * newQuantity;
          var newTotalPriceFormatted = formatter.format(newTotalPrice);
          $(this).closest("tr").find(".total-price").text(newTotalPriceFormatted);

          // Lấy giá trị của biến tổng cộng
          var price = parseFloat($("#total-price").text().replace(/\D/g, ""));

          var newTotalPrice = updateTotalPrice() - price;
          var totalFormatted = formatter.format(newTotalPrice);
          $("#total-price").text(totalFormatted);
        });

        $(".quantity-btn-giam").on("click", function () {
          var quantityElement = $(this).siblings(".soluong");
          var currentQuantity = parseInt(quantityElement.text());
          if (currentQuantity > 1) {
            var newQuantity = currentQuantity - 1;
            quantityElement.text(newQuantity);

            var productPriceElement = $(this).closest("tr").find(".product-price");
            var productPrice = parseFloat(productPriceElement.text().replace(/\D/g, ""));
            var newTotalPrice = productPrice * newQuantity;
            var newTotalPriceFormatted = formatter.format(newTotalPrice);
            $(this).closest("tr").find(".total-price").text(newTotalPriceFormatted);
            // Lấy giá trị của biến tổng cộng
            var price = parseFloat($("#total-price").text().replace(/\D/g, ""));

            var newTotalPrice = updateTotalPrice() - price;
            var totalFormatted = formatter.format(newTotalPrice);
            $("#total-price").text(totalFormatted);
          } else {
            alert("Không thể giảm số lượng dưới 0!")
          }

        });

        function updateTotalPrice() {
          var totalPrice = 0;
          $(".total-price").each(function () {
            var price = parseFloat($(this).text().replace(/\D/g, ""));
            totalPrice += price;
          });
          var totalFormatted = formatter.format(totalPrice);
          $("#total-price").text(totalFormatted);
          return parseFloat(totalPrice.toFixed(2));
        }

        for (var i = 0; i < products.length; i++) {
          var product = products[i];
          totalPrice += parseFloat(product.giaSp);
        }
        var totalFormatted = formatter.format(totalPrice);
        totalPriceElement.text(totalFormatted);

        // Xử lý nút xóa

        $(".btn-danger").on("click", function () {
          var row = $(this).closest("tr");
          var index = row.index();

          // Sử dụng SweetAlert để xác nhận xóa
          Swal.fire({
            title: "Bạn có chắc chắn muốn xóa sản phẩm này?",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "Xóa",
            cancelButtonText: "Hủy",
            reverseButtons: true
          }).then(function (result) {
            if (result.isConfirmed) {
              // Xóa hàng sản phẩm trong DOM
              row.remove();

              // Xóa sản phẩm khỏi danh sách sản phẩm trong localStorage
              products.splice(index, 1);

              // Cập nhật lại danh sách sản phẩm trong localStorage
              localStorage.setItem("products", JSON.stringify(products));

              // Tính toán và cập nhật lại tổng giá
              var totalPrice = 0;
              for (var i = 0; i < products.length; i++) {
                totalPrice += parseFloat(products[i].giaSp);
              }
              var totalFormatted = formatter.format(totalPrice);
              $("#total-price").text(totalFormatted);
            }
          });
          // Kiểm tra nếu không còn sản phẩm, hiển thị thông báo và ẩn các phần tử khác
          if (products.length === 0) {
            $("#giohangrong").show();
            $("#btn_giohang").hide();
            $("#tt_giohang").hide();
            $("#ft_giohang").hide();
          }
        });

      });

    </script>
    <!-- Thông tin đặt hàng -->
    <form method="POST" action="{{url('./thanh_toan_vnpay.vn')}}">
      <div class="row">
        <h2>Thông tin đặt hàng</h2>
        <div class="col-md-6">
          <div class="mb-3">
            <label for="name" class="form-label">Họ và tên</label>
            <input type="text" class="form-control" id="name">
          </div>

          <div class="mb-3">
            <label for="phone" class="form-label">Số điện thoại</label>
            <input type="tel" class="form-control" id="phone">
          </div>
          <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email">
          </div>
        </div>
        <div class="col-md-6">
          <div class="mb-3">
            <label for="province" class="form-label">Tỉnh/Thành phố</label>
            <select class="form-control" id="province">
              <option value="">Chọn tỉnh/thành phố</option>
              <!-- Tùy chỉnh dữ liệu từ API sẽ được thêm vào đây -->
            </select>
          </div>
          <div class="mb-3">
            <label for="district" class="form-label">Huyện/Quận</label>
            <select class="form-control" id="district">
              <option value="">Chọn huyện/quận</option>
              <!-- Tùy chỉnh dữ liệu từ API sẽ được thêm vào đây -->
            </select>
          </div>
          <div class="mb-3">
            <label for="ward" class="form-label">Xã/Phường</label>
            <select class="form-control" id="ward">
              <option value="">Chọn xã/phường</option>
              <!-- Tùy chỉnh dữ liệu từ API sẽ được thêm vào đây -->
            </select>
          </div>
          <div class="mb-3">
            <label for="specific-address" class="form-label">Địa chỉ cụ thể</label>
            <input type="text" class="form-control" id="specific-address">
          </div>
        </div>
      </div>
      <!-- Chọn phương thức thanh toán -->
      <div class="mb-3">
        <label class="form-label">Phương thức thanh toán</label>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="payment-method" id="direct-payment" value="direct-payment"
            checked>
          <label class="form-check-label" for="direct-payment">
            Thanh toán trực tiếp
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="payment-method" id="vnpay" value="vnpay">
          <label class="form-check-label" for="vnpay">
            VNPay
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="payment-method" id="momo" value="momo">
          <label class="form-check-label" for="momo">
            MoMo
          </label>
        </div>
        <div class="form-check">
          <input class="form-check-input" type="radio" name="payment-method" id="vietinbank" value="vietinbank">
          <label class="form-check-label" for="vietinbank">
            VietinBank
          </label>
        </div>
      </div>

      <button type="submit" name="redirect" id="dathang" class="btn btn-primary">Đặt hàng</button>
    </form>
  </div>
  <!-- End container -->

  <!-- Xử lý js cho chọn tỉnh -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script>
    // $("#dathang").on("click", function(){
    //   alert("Đã nhấn")
    // })
    $.ajax({
      url: 'https://vapi.vnappmob.com/api/province',
      method: 'GET',
      success: function (response) {
        var provinces = response.results;
        // Xử lý danh sách tỉnh/thành phố tại đây
        updateProvinceDropdown(provinces);
      },
      error: function (xhr, status, error) {
        console.log(error);
      }
    });
    function updateProvinceDropdown(provinces) {
      var dropdown = $('#province');

      $.each(provinces, function (index, province) {
        dropdown.append($('<option></option>').attr('value', province.province_id).text(province.province_name));
      });
    }
    // xử lý lấy huyện trong tỉnh đã chọn
    $('#province').on('change', function () {
      var selectedProvinceCode = $(this).val();
      // Gọi API để lấy danh sách huyện/quận dựa trên selectedProvinceCode
      $.ajax({
        url: 'https://vapi.vnappmob.com/api/province/district/' + selectedProvinceCode,
        method: 'GET',
        success: function (response) {
          var districts = response.results;
          // Xử lý danh sách huyện/quận tại đây
          updateDistrictDropdown(districts);
        },
        error: function (xhr, status, error) {
          console.log(error);
        }
      });
      // và cập nhật danh sách huyện/quận trong dropdown "#district"
    });


    // Xử lý hiện huyện 
    function updateDistrictDropdown(districts) {
      var dropdown = $('#district');

      dropdown.empty(); // Xóa tất cả các option hiện có trong dropdown

      dropdown.append($('<option></option>').attr('value', '').text('Chọn huyện/quận'));

      $.each(districts, function (index, district) {
        dropdown.append($('<option></option>').attr('value', district.district_id).text(district.district_name));
      });
    }

    // Xử lý lấy xã trong huyện đã chọn
    $('#district').on('change', function () {
      var selectedDistrictCode = $(this).val();
      // Gọi API để lấy danh sách xã/phường dựa trên selectedDistrictCode
      $.ajax({
        url: 'https://vapi.vnappmob.com/api/province/ward/' + selectedDistrictCode,
        method: 'GET',
        success: function (response) {
          var wards = response.results;
          // Xử lý danh sách xã/phường tại đây
          updateWardDropdown(wards);
        },
        error: function (xhr, status, error) {
          console.log(error);
        }
      });

      // và cập nhật danh sách xã/phường trong dropdown "#ward"
    });
    // 
    function updateWardDropdown(wards) {
      var dropdown = $('#ward');

      dropdown.empty(); // Xóa tất cả các option hiện có trong dropdown

      dropdown.append($('<option></option>').attr('value', '').text('Chọn xã/phường'));

      $.each(wards, function (index, ward) {
        dropdown.append($('<option></option>').attr('value', ward.ward_id).text(ward.ward_name));
      });
    }


  </script>
  <!-- Xử lý js cho thanh toán trực tiếp -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  <script>
    $(document).ready(function () {

      $("#dathang").on("click", function () {
        event.preventDefault(); // Ngăn chặn tải lại trang

        // Lấy giá trị của các trường
        var province = $("#province").val();
        var district = $("#district").val();
        var ward = $("#ward").val();
        var specificAddress = $("#specific-address").val();

        // Kiểm tra giá trị của các trường
        if (province === "" || district === "" || ward === "" || specificAddress === "") {
          // Hiển thị thông báo cho người dùng
          alert("Vui lòng chọn địa chỉ đầy đủ!");
          return; // Dừng lại và không tiếp tục xử lý đặt hàng
        } else {
          var email = localStorage.getItem("email");
          var user = localStorage.getItem("user");
          var madonhang = "madonhang1";

          if ($("#direct-payment").is(":checked")) {
            $.ajax({
              type: "POST",
              url: "./sendmail.php",
              data: {
                madonhang: madonhang,
                email: email,
                user: user
              },
              success: function (data) {
                // Hiển thị hộp thoại thông báo
                Swal.fire({
                  icon: 'success',
                  title: 'Thông báo',
                  text: 'Đơn hàng đang đợi duyệt. Vui lòng xem email!',
                  showConfirmButton: false,
                  timer: 0 // Tắt sau 2 giây
                });
              },
              error: function (xhr, status, error) {
                // Xử lý lỗi
              }
            });
          }
        }
        // Chọn vnpay
        var vnpay = $("#vnpay");
        if (vnpay.prop("checked")) {
          window.location.href = "./thanh_toan_vnpay.php";
        }
        // chọn mômp
        var momo = $("#momo");
        if (momo.prop("checked")) {
          window.location.href = "./thanh_toan_momo.php";
        }

      });
    });

    // Xử lý thêm vào cơ sở dữ liệu đạt hàng
    $(document).ready(function () {
      $("#dathang").on("click", function () {

        event.preventDefault(); // Ngăn chặn tải lại trang

        // Lấy giá trị của các trường
        var province = $("#province").val();
        var district = $("#district").val();
        var ward = $("#ward").val();
        var specificAddress = $("#specific-address").val();

        // Kiểm tra giá trị của các trường
        if (province === "" || district === "" || ward === "" || specificAddress === "") {
          // Hiển thị thông báo cho người dùng
          // alert("Vui lòng chọn địa chỉ đầy đủ!");
          return; // Dừng lại và không tiếp tục xử lý đặt hàng
        }
        var email = localStorage.getItem("email");

        var currentDate = new Date(); // Lấy ngày tháng hiện tại của máy tính

        var day = currentDate.getDate(); // Lấy ngày (từ 1 đến 31)
        var month = currentDate.getMonth() + 1; // Lấy tháng (từ 0 đến 11), cộng 1 để đổi về từ 1 đến 12
        var year = currentDate.getFullYear(); // Lấy năm (đầy đủ bốn chữ số)

        var ngaythang = year + "-" + month + "-" + day;

        // Lấy tổng tiền
        var tongtien = parseFloat($("#total-price").text().replace(/\D/g, ""));

        var diachi = $("#specific-address").val() + "," + $("#ward option:selected").text() + "," + $("#district option:selected").text() + "," + $("#province option:selected").text();

        $.ajax({
          type: "POST",
          url: "./php/xu_ly_dat_hang.php",
          data: { email: email, ngaythang: ngaythang, tongtien: tongtien, diachi: diachi },
          success: function (data) {

          }
        })
      })
    })
  </script>






  <!-- Beging Footer -->
  <footer>
    <div class="row">
      <div class="col-md-3">
        <h4 class="footer_title">Thông tin liên hệ</h4>
        <p>Tâm An - Nhà thuốc vì sức khỏe mọi người</p>
        <hr>
        <p><i class="fas fa-map-marker-alt"></i>Địa chỉ: Khóm 4, Phường 6 Tp.Cao Lãnh, Đồng Tháp</p>
        <p><i class="fas fa-phone"></i>Số điện thoại: 0564056521</p>
        <p><i class="fas fa-envelope"></i>Email: kaicapro@gmail.com</p>
      </div>
      <div class="col-md-3">
        <h4 class="footer_title">Hỗ trợ khách hàng</h4>
        <ul>
          <li><a href="./gioithieu.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Giới thiệu
              <hr>
            </a></li>
          <li> <a href="./chinhsachdoitra.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Chính sách đổi trả
              <hr>
            </a></li>
          <li> <a href="./chinhsachbaomat.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Chính sách bảo mật
              <hr>
            </a></li>
          <li> <a href="./chinhsachgiaohang.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Chính sách giao hàng
              <hr>
            </a></li>
        </ul>
      </div>
      <div class="col-md-3">
        <h4 class="footer_title">Tìm kiếm nhanh</h4>
        <ul>
          <li><button id="chuyentrang_tpcn">Thực phẩm chức năng</button></li>
          <li><button id="chuyentrang_tbyt">Dụng cụ y tế</button></li>
          <li>
            <img src="./img/bct.png" alt="Ảnh Bộ Công Thương" width="100px" height="10%" style="margin: -16px 0;">
            <p>GCN ĐĐKKDT SỐ 0672/HCM-DDKKDDD,
              22/07/2014, SỞ Y TẾ TP.HCM</p>
          </li>
        </ul>
      </div>
      <div class="col-md-3">
        <h4 class="footer_title">Ưu đãi hấp dẫn</h4>
        <ul>
          <li>Mỗi tháng chúng tôi đều có những đợt giảm giá dịch vụ và sản phẩm nhằm tri ân khách hàng. Để có thể cập
            nhật kịp thời những đợt giảm giá này, vui lòng nhập số điện thoại của bạn vào ô dưới đây.</li>
          <li><input id="emai_tv" type="text" placeholder="Để lại email để được tư vấn"><i id="email_tuvan"
              class="fas fa-paper-plane"></i></li>
        </ul>
      </div>
    </div>
    <hr>
    <p class="copy_right">Copyrights © 2023 by Truong An. Powered by Tâm An</p>
  </footer>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
      $("#email_tuvan").on("click", function () {
        var email_tv = $("#emai_tv").val(); // Lấy giá trị từ phần tử input có id "emai_tv"
        var trimmedEmail = email_tv.trim();
        $.ajax({
          type: "POST",
          url: "./sendmail_tuvan.php",
          data: { email: trimmedEmail },
          success: function (data) {
            Swal.fire({
              icon: 'success',
              title: 'Thông báo',
              text: 'Thông tin tư vấn đã gửi về mail của bạn. Vui lòng xem email!',
              showConfirmButton: false,
              timer: 0 // Tắt sau 2 giây
            });
          }
        })
      })

      // nhấn nút chuyển trang
      $("#chuyentrang_tpcn").on("click", function () {
        window.location.href = "./sanpham.php";
      })
      $("#chuyentrang_tbyt").on("click", function () {
        window.location.href = "./sanpham.php";
      })
    })
  </script>
  <!-- End Footer -->
</body>

</html>