$(document).ready(function () {
    function view_data() {
        $.post('./php/load_san_pham.php', function (data) {
            $("#load_view").html(data);
        })
    }
    // xóa
    $(document).on('click', '.button_del', function () {
        var id = $(this).val();
        var check = confirm("Bạn có chắc muốn xóa sản phẩm này không?");
        if (check == true) {
            $.post('./php/delete_san_pham.php', { id: id }, function (data) {
                view_data();
            })
        } else {
            return;
        }
    });

    // xóa khách hàng
    $(document).on('click', '.button_del_kh', function () {
        var id = $(this).val();
        var check = confirm("Bạn có chắc muốn xóa khách hàng này không?");
        if (check == true) {
            $.post('./php/xoa_kh.php', { id: id }, function (data) {
                $("#load_view").load("./php/load_khach_hang.php");
            })
        } else {
            return;
        }
    });


    // Cập nhật đơn hàng đã duyệt
    $(document).ready(function () {
        $(document).on('click', '.button_del_don_hang', function () {
            var chuoi = $(this).val();
            var mang = chuoi.split("$");

            var id = mang[0];
            var trangthai = mang[1];
            var email = mang[2];
            var tongtien = mang[3];

            $.ajax({
                method: "post",
                url: "./php/upd_trang_thai_don_hang.php",
                data: {id: id},
                success: function(data){
                    $("#load_view").load("./php/load_don_hang.php");
                }
            })
            // Gửi mail xác nhận cho người dùng
           
            $.ajax({
                type: "POST",
                url: "./senmail_duyet_don.php",
                data: {
                  id: id,
                  email: email,
                  tongtien: tongtien
                },
                success: function (data) {
                  // Hiển thị hộp thoại thông báo
                  Swal.fire({
                    icon: 'success',
                    title: 'Thông báo',
                    text: 'Đơn hàng đã được duyệt!',
                    showConfirmButton: false,
                    timer: 0 // Tắt sau 2 giây
                  });
                },
                error: function (xhr, status, error) {
                  // Xử lý lỗi
                }
              });
            
        })
    })

    $(document).ready(function () {
        $(document).on('click', '.btn_update', function () {
            var chuoi = $(this).val();
            var mang = chuoi.split("@");

            var id = mang[0];
            var name = mang[1];
            var dis_price = mang[2];
            var gia = mang[3];
            var ngan = mang[4];
            var chitiet = mang[5];
            var loai = mang[6];
            var donggoi = mang[7];
            var sl = mang[8];
            var hinh = mang[9];

            $("#upd-product-form").show();

            // Thiết lập giá trị cho thuộc tính placeholder của các trường input và textarea
            $('#ten').val(name);
            $('#gia').val(dis_price);
            $('#giamgia_sp').val(gia);
            $('#ngan').val(ngan);
            $('#chitiet').val(chitiet);
            $("#loaisp").val(loai);
            $('#donggoi').val(donggoi);
            $('#sl').val(sl);
            $('#hinh').val(hinh);

            $('#update-btn').on("click", function () {
                var ma = id;
                var tensp = $.trim($("#ten").val());
                var giamgia = $.trim($("#giamgia_sp").val());
                var thongtinngan = $.trim($("#ngan").val());
                var thongtinchitiet = $.trim($("#chitiet").val());
                var loaisp = $.trim($("#loaisp option:selected").text());
                var cachdonggoi = $.trim($("#donggoi").val());
                var soluong = $.trim($("#sl").val());
                var giasp = $.trim($("#gia").val());
                var hinhsp = $.trim($("#hinh").val());
                // alert(ma + tensp + giamgia+ thongtinchitiet+ loai+ cachdonggoi+ soluong+giasp+hinhsp)
                $.ajax({
                    url: './php/update_san_pham.php',
                    method: 'POST',
                    data: {
                        id: ma,
                        tensp: tensp,
                        giasp: giasp,
                        giamgia: giamgia,
                        thongtinngan: thongtinngan,
                        thongtinchitiet: thongtinchitiet,
                        loaisp: loaisp,
                        cachdonggoi: cachdonggoi,
                        soluong: soluong,
                        hinhsp: hinhsp
                    },
                    success: function (data) {
                        alert("Đã cập nhật thành công");
                        view_data();
                    },
                    error: function (xhr, status, error) {
                        var errorMessage = xhr.status + ': ' + xhr.statusText;
                        alert('Cập nhật thất bại. Lỗi: ' + errorMessage);
                    }
                });

            });
        });
    });

    // thêm
    $(document).ready(function () {
        $("#add-product-btn").on("click", function () {
            // $("#add-product-form").show();
            alert("đã nhấn")
            $("#hien").show();

        })
        $('#submit-btn').on("click", function () {

            var tensp = $.trim($("#tensp").val());
            var giamgia = $.trim($("#giamgia").val());
            var thongtinngan = $.trim($("#thongtinngan").val());
            var thongtinchitiet = $.trim($("#thongtinchitiet").val());
            var loaisp = $.trim($("#loaisp option:selected").text());
            var cachdonggoi = $.trim($("#cachdonggoi").val());
            var soluong = $.trim($("#soluong").val());
            var giasp = $.trim($("#giasp").val());
            var hinhsp = $.trim($("#hinhsp").val());


            if (tensp == '' || giamgia == '' || thongtinngan == '' || thongtinchitiet == '' || loaisp == '' || cachdonggoi == '' || soluong == '' || giasp == '' || hinhsp == '') {
                alert('Vui lòng nhập đầy đủ thông tin!');
                event.preventDefault();
                // return;
            } else if (!(/^(http:\/\/|https:\/\/)/.test(hinhsp))) {
                alert("Hình nhập vào phải là một đường link");
                event.preventDefault();
            } else if (giamgia > 50) {
                alert("Trong có vẻ bạn đã giảm giá quá nhiều bạn cần xem lại!");
                event.preventDefault();
            }
            else {
                $.post('./php/add_san_pham.php', { tensp: tensp, giasp: giasp, giamgia: giamgia, thongtinngan: thongtinngan, thongtinchitiet: thongtinchitiet, loaisp: loaisp, cachdonggoi: cachdonggoi, soluong: soluong, hinhsp: hinhsp }, function (data) {
                    alert("Đã thêm thành công!!");
                    view_data();

                    // Ẩn form sau khi thêm sản phẩm thành công
                    // $("#add-product-form").hide();
                })
            }

        })
    })
});