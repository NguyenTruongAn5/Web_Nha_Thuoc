<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
  <link rel="stylesheet" href="./font/fontawesome-free-6.3.0-web/css/all.min.css">
  <link rel="stylesheet" href="./css/reset.css">
  <link rel="stylesheet" href="./css/product.css">
  <link rel="stylesheet" href="./css/sanpham.css">
  <title>Sản Phẩm</title>

</head>

<body>
  <!-- Beging Header -->
  <header class="header">
    <div class="header-logo">
      <a href="./index.php">
        <img src="./img/logotrang.png" alt="Ảnh LoGo" class="logo-img" width="36%" height="36%">
      </a>
    </div>
    <div class="header-main">
      <ul>
        <li class="header-main-content">
          <button id="hien" class="button_history">
            <span id="ten_user">Đăng nhập</span>
          </button>
        </li>

        <li id="btn_dangxuat" class="header-main-content" style="display: none">
          <button class="button_history">
            <span id="ten_user">Đăng xuất</span>
          </button>
        </li>

        <li id="btn_dangki" class="header-main-content">
          <button class="button_history">
            <span id="ten_user">Đăng kí</span>
          </button>
        </li>

        <li class="header-main-content"><a href="./giohang.php">
            <i class="fa-solid fa-cart-shopping"></i>
            <div id="cart-quantity" class="header-main-bell">2</div>
            Giỏ hàng
          </a></li>
      </ul>
    </div>
    <!-- Xử lý thông báo giỏ hàng -->
    <script>
      var storedProducts = localStorage.getItem("products");
      var products = JSON.parse(storedProducts);
      var numberOfProducts = products.length;

      // Gán giá trị của numberOfProducts vào phần tử HTML
      var cartQuantityElement = document.getElementById("cart-quantity");
      cartQuantityElement.textContent = numberOfProducts.toString();
    </script>
  </header>

  <nav class="navbar">
    <ul>
      <li><a id="thuoc" href="#">Thuốc</a></li>
      <li><a id="tpcn" href="#">Thực phẩm chức năng</a></li>
      <li><a id="tbyt" href="#">Thiết bị dụng cụ y tế</a></li>
      <li><a id="mypham" href="#">Mỹ phẩm</a></li>
      <!-- <li>
          <form>
            <input type="text" placeholder="Tìm kiếm">
            <button type="submit"><i class="fas fa-search"></i></button>
          </form>
        </li> -->
    </ul>
  </nav>
  <!-- End Header -->

  <!-- Beging container -->
  <div class="container">
    <div class="col_3">
      <!-- Menu lọc sản phẩm -->
      <div class="menu_product">
        <h2>Bộ lọc sản phẩm</h2>
        <hr>
        <ul>
          <li>
            <input id="tatca" type="checkbox" value="tatca" name="tatca">
            <label for="tatca">Tất cả</label>
          </li>
          <li>
            <input id="cb_thuoc" type="checkbox" value="thuoc" name="thuoc">
            <label for="thuoc">Thuốc</label>
          </li>
          <li>
            <input id="cb_tpcn" type="checkbox" value="tpcn" name="tpcn">
            <label for="tpcn">Thực phẩm chức năng</label>
          </li>
          <li>
            <input id="cb_tbyt" type="checkbox" value="tbyt" name="tbyt">
            <label for="tbyt">Thiết bị y tế</label>
          </li>
          <li>
            <input id="cb_mp" type="checkbox" value="mypham" name="mypham">
            <label for="mypham">Mỹ Phẩm</label>
          </li>
        </ul>
      </div>

      <!-- Menu lọc giá -->
      <div class="menu_price">
        <h2>Bộ lọc giá</h2>
        <hr>
        <ul>
          <li>
            <input id="radio_100" type="radio" name="price" value="duoi100">
            <label for="price">Dưới 100 nghìn</label>
          </li>
          <li>
            <input id="radio_200" type="radio" name="price" value="100den200">
            <label for="price">Từ 100 đến 200 nghìn</label>
          </li>
          <li>
            <input id="radio_500" type="radio" name="price" value="200den500">
            <label for="price">Từ 200 đến 500 nghìn</label>
          </li>
          <li>
            <input id="radiotren500" type="radio" name="price" value="tren500">
            <label for="price">Trên 500 nghìn</label>
          </li>
        </ul>
      </div>
    </div>

    <!-- Hiện sản phẩm -->
    <div class="col_9">
      <div id="load_sanpham" class="sanpham">
        <?php
        include "./php/load_tat_ca_sp.php";
        // $search= $_GET['search'];
        // include "./php/{$search}.php";
        // include "./php/tpcn_load.php";
        ?>
      </div>
    </div>
  </div>


  <!-- End container -->

  <!-- Xử lý js -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script>

    $(document).ready(function () {

      //Nhấn chuyển trang
      $("#thuoc").on("click", function () {
        $("#cb_thuoc").prop("checked", true);
        $("#load_sanpham").load("./php/thuoc_load.php")
      })

      $("#tpcn").on("click", function () {
        $("#cb_tpcn").prop("checked", true);
        $("#load_sanpham").load("./php/tpcn_load.php")
      })

      $("#tbyt").on("click", function () {
        $("#cb_tbyt").prop("checked", true);
        $("#load_sanpham").load("./php/tbyt_load.php")
      })

      $("#mypham").on("click", function () {
        $("#cb_mp").prop("checked", true);
        $("#load_sanpham").load("./php/mypham_load.php")
      })

      // load thuốc
      $("#cb_thuoc").change(function () {
        if (this.checked) {
          $("#load_sanpham").load("./php/thuoc_load.php")
        } else {
        }
      })

      // load thực phẩm chức năng
      $("#cb_tpcn").change(function () {
        if (this.checked) {
          $("#load_sanpham").load("./php/tpcn_load.php")
        } else {
        }
      })

      // load thiết bị y tế
      $("#cb_tbyt").change(function () {
        if (this.checked) {
          $("#load_sanpham").load("./php/tbyt_load.php")
        } else {
        }
      })

      // load mỹ phẩm
      $("#cb_mp").change(function () {
        if (this.checked) {
          $("#load_sanpham").load("./php/mypham_load.php")
        } else {
        }
      })
      $("#tatca").change(function () {
        location.reload();
        if (this.checked) {
          $("#cb_mp").prop("checked", false);
          $("#cb_thuoc").prop("checked", false);
          $("#cb_tpcn").prop("checked", false);
          $("#cb_tbyt").prop("checked", false);
        } else {
        }
      })

      //load sản phẩm dưới 100 k
      $("#radio_100").change(function () {
        if (this.checked) {
          $("#load_sanpham").load("./php/load_sp_duoi100.php")
        } else {
        }
      })

      //load sản phẩm dưới  > 100 và < 200
      $("#radio_200").change(function () {
        if (this.checked) {
          $("#load_sanpham").load("./php/load_sp_1den2.php")
        } else {
        }
      })


      //load sản phẩm dưới  > 200 và < 500
      $("#radio_500").change(function () {
        if (this.checked) {
          $("#load_sanpham").load("./php/load_sp_2den5.php")
        } else {
        }
      })

      //load sản phẩm trên 500
      $("#radiotren500").change(function () {
        if (this.checked) {
          $("#load_sanpham").load("./php/load_sp_tren5.php")
        } else {
        }
      })
    });


  </script>
  <!-- end xử lí js -->


  
  <!-- Beging Footer -->
  <footer>
    <div class="row">
      <div class="col-md-3">
        <h4 class="footer_title">Thông tin liên hệ</h4>
        <p>Tâm An - Nhà thuốc vì sức khỏe mọi người</p>
        <hr>
        <p><i class="fas fa-map-marker-alt"></i>Địa chỉ: Khóm 4, Phường 6 Tp.Cao Lãnh, Đồng Tháp</p>
        <p><i class="fas fa-phone"></i>Số điện thoại: 0564056521</p>
        <p><i class="fas fa-envelope"></i>Email: kaicapro@gmail.com</p>
      </div>
      <div class="col-md-3">
        <h4 class="footer_title">Hỗ trợ khách hàng</h4>
        <ul>
          <li><a href="./gioithieu.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Giới thiệu
              <hr>
            </a></li>
          <li> <a href="./chinhsachdoitra.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Chính sách đổi trả
              <hr>
            </a></li>
          <li> <a href="./chinhsachbaomat.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Chính sách bảo mật
              <hr>
            </a></li>
          <li> <a href="./chinhsachgiaohang.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Chính sách giao hàng
              <hr>
            </a></li>
        </ul>
      </div>
      <div class="col-md-3">
        <h4 class="footer_title">Tìm kiếm nhanh</h4>
        <ul>
          <li><button id="chuyentrang_tpcn">Thực phẩm chức năng</button></li>
          <li><button id="chuyentrang_tbyt">Dụng cụ y tế</button></li>
          <li>
            <img src="./img/bct.png" alt="Ảnh Bộ Công Thương" width="100px" height="10%" style="margin: -16px 0;">
            <p>GCN ĐĐKKDT SỐ 0672/HCM-DDKKDDD,
              22/07/2014, SỞ Y TẾ TP.HCM</p>
          </li>
        </ul>
      </div>
      <div class="col-md-3">
        <h4 class="footer_title">Ưu đãi hấp dẫn</h4>
        <ul>
          <li>Mỗi tháng chúng tôi đều có những đợt giảm giá dịch vụ và sản phẩm nhằm tri ân khách hàng. Để có thể cập
            nhật kịp thời những đợt giảm giá này, vui lòng nhập số điện thoại của bạn vào ô dưới đây.</li>
          <li><input id="emai_tv" type="text" placeholder="Để lại email để được tư vấn"><i id="email_tuvan"
              class="fas fa-paper-plane"></i></li>
        </ul>
      </div>
    </div>
    <hr>
    <p class="copy_right">Copyrights © 2023 by Truong An. Powered by Tâm An</p>
  </footer>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
      $("#email_tuvan").on("click", function () {
        var email_tv = $("#emai_tv").val(); // Lấy giá trị từ phần tử input có id "emai_tv"
        var trimmedEmail = email_tv.trim();
        $.ajax({
          type: "POST",
          url: "./sendmail_tuvan.php",
          data: { email: trimmedEmail },
          success: function (data) {
            Swal.fire({
              icon: 'success',
              title: 'Thông báo',
              text: 'Thông tin tư vấn đã gửi về mail của bạn. Vui lòng xem email!',
              showConfirmButton: false,
              timer: 0 // Tắt sau 2 giây
            });
          }
        })
      })

      // nhấn nút chuyển trang
      $("#chuyentrang_tpcn").on("click", function(){
        window.location.href = "./sanpham.php";
      })
      $("#chuyentrang_tbyt").on("click", function(){
        window.location.href = "./sanpham.php";
      })
    })
  </script>
  <!-- End Footer -->
</body>

</html>