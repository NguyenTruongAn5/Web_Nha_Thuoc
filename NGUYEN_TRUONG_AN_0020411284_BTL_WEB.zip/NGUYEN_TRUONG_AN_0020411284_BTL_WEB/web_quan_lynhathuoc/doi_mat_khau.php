<!DOCTYPE html>
<html>

<head>
    <title>Quên mật khẩu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="./font/fontawesome-free-6.3.0-web/css/all.min.css">
    <!-- Các tài nguyên SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
    <style>
        /* login */

        body {
            background-color: #ccc;
        }

        .container {
            position: fixed;
            top: 0;
            left: 0;
            right: 0px;
            width: 100%;
            height: 80%;
            max-height: 640px;
            z-index: 9999;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow-x: hidden;
            overflow-y: auto;

        }


        .container>form {
            /* CSS cho form đăng nhập */
            z-index: 10000;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            width: 32%;
            height: 72%;
            border-radius: 12px;
        }

        .icon_close {
            margin-left: 70%;
            border: none;
            background-color: #fff;
        }

        .container>form>h2 {
            display: flex;
            justify-content: center;
            margin-top: 4%;
            font-size: 0.8rem;
            color: var(--primary-color);
            font-weight: bold;
        }

        .form-group>h3 {
            font-size: .6rem;
            text-align: left;
            margin-left: 6%;
        }

        .form-group>a {
            font-size: .8rem;
            text-decoration: none;
        }

        .form-group>a>img {
            display: flex;
            margin: auto;
        }

        .form-group>input {
            width: 90%;
            height: 36px;
            display: flex;
            margin: auto;
            border: .5px solid #ccc;
            border-radius: 8px;
            font-size: .8rem;
            padding-left: 2%;

        }

        .form-group>input:focus {
            outline: solid var(--primary-color) 1px;
        }

        .btn_login {
            background-color: blue;
            border: none;
            width: 40%;
            height: 12%;
            color: #fff;
            border-radius: 16px;
            position: relative;
            left: 50%;
            top: 20px;
            transform: translate(-50%, -50%);
            margin-top: 3%;
            font-size: 1rem;
        }

        /* end login */
    </style>

</head>

<body>
    <?php
    $thongbao = "";
    if (isset($_POST['guiyeucau'])) {
        $email = $_POST['email'];
        include "./php/connect.php";

        $sql = "SELECT * FROM khachhang WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        $count = $result->num_rows; // Sử dụng phương thức num_rows() để đếm số hàng trả về
        if ($count == 0) {
            $thongbao = "Email của bạn không tồn tại trong hệ thống";
        } else {
            include "./send_otp.php";


            $randomNumber1 = rand(0, 9);
            $randomNumber2 = rand(0, 9);
            $randomNumber3 = rand(0, 9);
            $randomNumber4 = rand(0, 9);
            $randomNumber5 = rand(0, 9);
            $randomNumber6 = rand(0, 9);

            $number = $randomNumber1 . $randomNumber2 . $randomNumber3 . $randomNumber4 . $randomNumber5 . $randomNumber6;
            $ten = "Quý khách hàng";
            $noidung = "Mã OTP của quý khách là $number";
            // Mã hóa giá trị OTP bằng MD5
            $hashedOTP = md5($number);

            // Tạo mã JavaScript để lưu giá trị mã hóa vào localStorage
            $jsCode = "
                <script>
                    localStorage.setItem('otp', '" . $hashedOTP . "');
                    localStorage.setItem('email_mk', '" . $email . "');
                </script>
            ";

            // In mã JavaScript và nhúng vào trang web
            echo $jsCode;
            GuiMail($noidung, $email, $ten);
            echo '<script>window.location.href = "./nhap_ma_otp.php";</script>';
            exit();

        }
    }
    ?>

    <!-- Login -->
    <div class="container">
        <form method="post" id="login-form">
            <h2>
                Đổi mật khẩu
            </h2>
            <?php if ($thongbao != "") { ?>
                <div class="alert alert-danger">
                    <?php echo $thongbao ?>
                </div>
            <?php } ?>
            <hr>
            <div class="form-group">
                <a href="./index.php"><img src="./img/logoxanh.png" alt="ảnh logo" width="16%" height="32%"></a>
                <h3>Nhập vào tài khoản gmail</h3>
                <input value="<?php if (isset($email) == true)
                    echo $email ?>" style="margin-bottom: 2%;" name="email" type="email" id="email"
                        placeholder="Nhập số điện thoại của bạn" required>

                    <button value="nutgui" name="guiyeucau" id="gui_otp" class="btn_login">Gửi yêu cầu</button>
                </div>
                <!-- <a class="form_a" href="#">Quên mật khẩu?</a> -->

            </form>
        </div>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"
            integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    </body>

    </html>