<?php 
include 'connect.php';
$user = $_POST['user'];
$pass = $_POST['pass'];
$sql = "SELECT ten_kh, matkhau, quyen FROM khachhang WHERE `khachhang`.`sdt` = '$user'";
$query = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($query);
$taikhoan = $row['ten_kh'];
$matkhau = $row['matkhau'];
$quyen = $row['quyen'];
if ($pass == $matkhau){
    if($quyen == "admin"){
       echo "admin".include 'admin.php';
    }else if($quyen == "khach"){
       echo "admin". include 'index.php';
    }
}else{
    $html = '
    <div class="container">
      <form id="login-form">
        <h2>
          Đăng Nhập Hoặc Tạo Tài Khoản
          <button class="icon_close" id="an">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </h2>
        <hr>
        <div class="form-group">
          <img src="./img/logo.png" alt="ảnh logo" width="30%" height="50%">
          <h3>Mật khẩu không chính xác vui lòng nhập lại!!</h3>
          <input type="tel" id="pass" name="phone" placeholder="Nhập mật khẩu" required>
        </div>

        <button id="btn_pass" class="button_login" type="submit">Đăng nhập</button>
      </form>
    </div>';
  echo "sai mật khẩu". $html;

}
?>