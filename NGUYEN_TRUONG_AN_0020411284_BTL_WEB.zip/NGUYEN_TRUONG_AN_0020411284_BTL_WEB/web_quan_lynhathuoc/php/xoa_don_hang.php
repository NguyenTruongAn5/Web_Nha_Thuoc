<?php 
include 'connect.php';
$id = $_POST['ma'];
$sql = "DELETE FROM hoadon WHERE `hoadon`.`ma_hoadon` = '$id'";
$query = mysqli_query($conn, $sql);
if ($query){
    echo "Đã hủy đơn hàng thành công!";
}else{
    echo "Hủy đơn hàng thất bại";
}
?>