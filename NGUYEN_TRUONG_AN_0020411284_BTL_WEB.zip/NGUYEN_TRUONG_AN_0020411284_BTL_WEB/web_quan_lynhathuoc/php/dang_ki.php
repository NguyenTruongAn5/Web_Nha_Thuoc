<?php 
include 'connect.php';
$acc = $_POST['user'];
$sql = "SELECT * FROM khachhang WHERE `khachhang`.`sdt` = '$acc' or 'email' = '$acc'";
$query = mysqli_query($conn, $sql);
if(mysqli_num_rows($query) > 0){
    echo "co";
}else {
    echo "khong";
}
?>