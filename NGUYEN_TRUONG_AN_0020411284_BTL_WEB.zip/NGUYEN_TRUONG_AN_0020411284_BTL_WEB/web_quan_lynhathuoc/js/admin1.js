$(document).ready(function () {
  // trở về trang chủ
  $("#home").on("click", function () {
    $("#home").css({
      "background-color": "#000",
      "color": "#fff"
    });
    $("#show_home").load("./index.php");

  })

  // tìm kiếm
  $("#btn_search").on("click", function () {
    var search = $.trim($("#input_search").val());
    $.post('./php/search_data.php', { search: search }, function (data) {
      $("#load_view").html(data);
      // alert(data)
    })
    event.preventDefault();
  })

  // load data san phẩm
  $("#sanpham").on("click", function () {
    $("#title_quanly").text("Quản lý sản phẩm")
    $("#add_show_admin").show();
    $("#hien_thong_ke").hide();
    $("#chart").hide()


    $("#sanpham").css({
      "background-color": "#000",
      "color": "#fff"
    });
    $("#donhang").css({
      "background-color": "#FC7300",
      "color": "#fff"
    });
    $("#khachhang").css({
      "background-color": "#FC7300",
      "color": "#fff"
    });
    $("#thongke").css({
      "background-color": "#FC7300",
      "color": "#fff"
    });
    $("#load_view").load("./php/load_san_pham.php");
  })
  // nút đơn hàng
  $("#donhang").on("click", function () {
    $("#title_quanly").text("Quản lý đơn hàng")
    $("#add_show_admin").hide();
    $("#hien_thong_ke").hide();
    $("#chart").hide()

    $("#product_boss").css({
      "display": "block"
    })
    $("#donhang").css({
      "background-color": "#000",
      "color": "#fff"
    });
    $("#khachhang").css({
      "background-color": "#FC7300",
      "color": "#fff"
    });
    $("#thongke").css({
      "background-color": "#FC7300",
      "color": "#fff"
    });
    $("#sanpham").css({
      "background-color": "#FC7300",
      "color": "#fff"
    });
    $("#load_view").load("./php/load_don_hang.php");
  })
  // nút thống kê
  $("#thongke").on("click", function () {
    $("#title_quanly").text("Thống kê đơn hàng")
    $("#add_show_admin").hide();
    $("#hien_thong_ke").hide();
    $("#chart").show()
    // $("#product_boss").css({
    //   "display": "block"
    // })
    $("#donhang").css({
      "background-color": "#FC7300",
      "color": "#fff"
    });
    $("#khachhang").css({
      "background-color": "#FC7300",
      "color": "#fff"
    });
    $("#thongke").css({
      "background-color": "#000",
      "color": "#fff"
    });
    $("#sanpham").css({
      "background-color": "#FC7300",
      "color": "#fff"
    });
    $("#load_view").load("./php/bieu_do_thong_ke.php");
  })
  // nút khách hang
  $("#khachhang").on("click", function () {
    // $("#product_boss").css({
    //   "display": "block"
    // })
    $("#title_quanly").text("Quản lý khách hàng")
    $("#add_show_admin").hide();
    $("#hien_thong_ke").hide();
    $("#chart").hide()
    $("#donhang").css({
      "background-color": "#FC7300",
      "color": "#fff"
    });
    $("#khachhang").css({
      "background-color": "#000",
      "color": "#fff"
    });
    $("#thongke").css({
      "background-color": "#FC7300",
      "color": "#fff"
    });
    $("#sanpham").css({
      "background-color": "#FC7300",
      "color": "#fff"
    });
    $("#load_view").load("./php/load_khach_hang.php");
  })
})