<?php
include "connect.php";
$select_ma = "SELECT ma_kh from khachhang order by ma_kh desc limit 1";
$result_query = mysqli_query($conn, $select_ma);
$result_ma = mysqli_fetch_assoc($result_query);
$ma = $result_ma["ma_kh"];

// Tách số cuối cùng của chuỗi
$last_number = substr($ma, -2); // "01"

// Tăng số cuối cùng lên 1
$new_number = sprintf("%02d", intval($last_number) + 1); // "02"

// Tạo mã mới
$new_id = "khachhang" . $new_number; // "thuoc02"
$quyen = "khach";

if (isset($_POST['name'], $_POST['phone'], $_POST['pass'], $_POST['cof_pass'])) {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $pass = $_POST['pass'];
    $cof_pass = $_POST['cof_pass'];
    
    $sql = "INSERT into khachhang values ('$new_id', '$name', '$phone', '$quyen', '$pass', '$cof_pass')";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo 1;
    } else {
        echo 0;
    }
} else {
    // Xử lý lỗi khi các trường không tồn tại đầy đủ
}
echo $name;

?>