<?php
// Thông tin kết nối đến cơ sở dữ liệu
include "connect.php";
// Lấy dữ liệu từ cơ sở dữ liệu
$sql = "SELECT * FROM hoadon ORDER BY ngaymua DESC";// giả sử id sản phẩm là 1
$result = mysqli_query($conn, $sql);

$table = '
<div class="cart_product_title scrollbar">
<table>
<thead class="table_fixed">
  <tr>
    <th>Mã ĐH</th>
    <th>Tài khoản KH</th>
    <th>Ngày đặt</th>
    <th>Tổng tiền</th>
    <th>Địa chỉ giao hàng</th>
    <th>Trạng thái đơn hàng</th>
    <th></th>
  </tr>
</thead>
<tbody>';

// Kiểm tra kết quả truy vấn
if (mysqli_num_rows($result) > 0) {
  // Lấy các giá trị cần thiết từ hàng dữ liệu đầu tiên (giả sử chỉ có 1 sản phẩm)
  while ($row = mysqli_fetch_assoc($result)) {
    $ma = $row["ma_hoadon"];
    $emai = $row["email_kh"];
    $ngaymua = $row["ngaymua"];
    $tongtien = $row["tongtien"];
    $trangthai = $row["trangthai"];
    $diachigiaohang = $row["diachigiaohang"];


    // Thay thế các giá trị vào đoạn mã HTML
    $table .= '
          
            <tr>
              <td id="ma_sp">' . $ma . '</td>
              <td>' . $emai . '</td>
              <td>' . $ngaymua . '</td>
              <td>' . $tongtien . '</td>
              <td>' . $diachigiaohang . '</td>
              <td>' . $trangthai . '</td>
              <td>
                <button style = "max-width: 80%" id="duyetdon" class="button_del_don_hang" value="' . $ma . '$' . $trangthai . '$' . $emai . '$' . $tongtien . '">Duyệt đơn</i></button>
              </td>
            </tr>
          ';
  }

} else {
  // Xử lý trường hợp không có dữ liệu
  $table .= '<tr><td colspan="12">Không có dữ liệu</td></tr>';
}

$table .= '</tbody></table></div>';

// In dữ liệu sản phẩm ra màn hình
echo $table;

// Đóng kết nối đến cơ sở dữ liệu
$conn->close();
?>

<script>
  $(document).ready(function () {
    $('.button_del_don_hang').each(function () {
      var chuoi = $(this).val();
      var mang = chuoi.split("$");

      var id = mang[0];
      var trangthai = mang[1];
      var email = mang[2];
      var tongtien = mang[3];

      // Kiểm tra nếu trạng thái đã duyệt thì thực hiện thay đổi màu nền và nội dung
      if (trangthai !== 'Chưa duyệt') {
        $(this).css("background-color", 'green');
        $(this).html("Đã duyệt");
        $(this).prop("disabled", true);
      }
    });
  });

</script>