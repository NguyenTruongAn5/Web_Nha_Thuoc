<?php
// Thông tin kết nối đến cơ sở dữ liệu
include "connect.php";
// Lấy dữ liệu từ cơ sở dữ liệu
$sql = "SELECT * FROM khachhang WHERE quyen LIKE 'khach' ORDER BY ma_kh DESC";// giả sử id sản phẩm là 1
$result = mysqli_query($conn, $sql);

$table = '
<div class="cart_product_title scrollbar">
<table>
<thead class="table_fixed">
  <tr>
    <th>Mã KH</th>
    <th>Tên khách hàng</th>
    <th>Số điện thoại</th>
    <th>Email</th>
    <th>Quyền</th>
    <th></th>
  </tr>
</thead>
<tbody>';

// Kiểm tra kết quả truy vấn
if (mysqli_num_rows($result) > 0) {
    // Lấy các giá trị cần thiết từ hàng dữ liệu đầu tiên (giả sử chỉ có 1 sản phẩm)
    while ($row = mysqli_fetch_assoc($result)) {
        $ma = $row["ma_kh"];
        $ten = $row["ten_kh"];
        $sdt = $row["sdt"];
        $mail = $row["email"];
        $quyen = $row["quyen"];


        // Thay thế các giá trị vào đoạn mã HTML
        $table .= '
          
            <tr>
              <td id="ma_sp">' . $ma . '</td>
              <td>' . $ten . '</td>
              <td>' . $sdt . '</td>
              <td>' . $mail . '</td>
              <td>' . $quyen . '</td>
              <td>
                <button class="button_del_kh" value="' . $ma . '"><i class="fa-solid fa-trash"></i></button>
             </td>
            </tr>
          ';
    }
    // <button class="btn_update_kh" value ="' . $ma . '"><i class="fa-solid fa-pen-to-square"></i></button>

} else {
    // Xử lý trường hợp không có dữ liệu
    $table .= '<tr><td colspan="12">Không có dữ liệu</td></tr>';
}

$table .= '</tbody></table></div>';

// In dữ liệu sản phẩm ra màn hình
echo $table;

// Đóng kết nối đến cơ sở dữ liệu
$conn->close();
?>