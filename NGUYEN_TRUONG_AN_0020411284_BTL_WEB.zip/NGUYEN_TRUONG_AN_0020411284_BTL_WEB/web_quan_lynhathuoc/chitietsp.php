<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
    crossorigin="anonymous"></script>
  <link rel="stylesheet" href="./font/fontawesome-free-6.3.0-web/css/all.min.css">
  <link rel="stylesheet" href="./css/reset.css">
  <link rel="stylesheet" href="./css/product.css">
  <title>Chi tiết sản phẩm</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script>
    $(document).ready(() => {
      $('.img-scale').attr('src', $('img').first().attr('src'))

      //Gắn sự kiện click cho toàn thẻ img
      $('img').on('click', e => {
        $('.img-scale').attr('src', e.target.src)
      })
    })
  </script>
  <style>
    body {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    }

    #slide .fa-chevron-circle-left {
      position: absolute;
      top: 70%;
      left: 2%;
      font-size: 2rem;
      color: #9299a8;
    }

    #slide .fa-chevron-circle-right {
      position: absolute;
      top: 70%;
      left: 30%;
      font-size: 2rem;
      color: #9299a8;
    }

    #btn_pre:hover,
    #btn_next:hover {
      cursor: pointer;
    }

    .mota {
      font-size: 1rem;
      font-weight: bold;
    }

    .thongtinngan {
      font-size: 1rem;
      font-weight: 400;
    }

    .btn {
      display: block;
      width: 100%;
      height: 100%;
    }

    .btn_chonmua,
    .btn_giohang {
      background-color: var(--primary-color);
      width: 20%;
      height: 12%;
      display: inline-block;
      outline: none;
      border: 0;
      border-radius: 8px;
      color: #fff;
      font-size: 1rem;
      margin-right: 8%;
    }

    .btn .btn_giohang :hover {
      color: var(--primary-color);
      background-color: #fff;
    }

    .btn .btn_chonmua :hover {
      color: var(--primary-color);
      background-color: #fff;
    }
  </style>

</head>

<body>
  <!-- Beging Header -->
  <header class="header">
    <div class="header-logo">
      <a href="./index.php">
        <img src="./img/logotrang.png" alt="Ảnh LoGo" class="logo-img" width="36%" height="36%">
      </a>
    </div>
    <div class="header-main">
      <ul>
        <li class="header-main-content">
          <button id="hien" class="button_history">
            <span id="ten_user">Đăng nhập</span>
          </button>
        </li>

        <li id="btn_dangxuat" class="header-main-content" style="display: none">
          <button class="button_history">
            <span id="ten_user">Đăng xuất</span>
          </button>
        </li>

        <li id="btn_dangki" class="header-main-content">
          <button class="button_history">
            <span id="ten_user">Đăng kí</span>
          </button>
        </li>

        <li class="header-main-content"><a href="./giohang.php">
            <i class="fa-solid fa-cart-shopping"></i>
            <div id="cart-quantity" class="header-main-bell">2</div>
            Giỏ hàng
          </a></li>
      </ul>
    </div>
    <!-- Xử lý thông báo giỏ hàng -->
    <script>
      var storedProducts = localStorage.getItem("products");
      var products = JSON.parse(storedProducts);
      var numberOfProducts = products.length;

      // Gán giá trị của numberOfProducts vào phần tử HTML
      var cartQuantityElement = document.getElementById("cart-quantity");
      cartQuantityElement.textContent = numberOfProducts.toString();
    </script>
  </header>

  <nav class="navbar">
    <ul>
      <li><a href="./sanpham.php?search=thuoc_load">Thuốc</a></li>
      <li><a href="./sanpham.php?search=thuoc_load">Thực phẩm chức năng</a></li>
      <li><a href="./sanpham.php?search=thuoc_load">Thiết bị dụng cụ y tế</a></li>
      <li><a href="./sanpham.php?search=thuoc_load">Mỹ phẩm</a></li>
      <!-- <li>
          <form>
            <input type="text" placeholder="Tìm kiếm">
            <button type="submit"><i class="fas fa-search"></i></button>
          </form>
        </li> -->
    </ul>
  </nav>
  <!-- End Header -->

  <!-- Lấy dữ liệu ảnh -->
  <?php
  include "./php/connect.php";
  $masp = $_GET['masp'];
  $sql = "SELECT hinh, hinh_chi_tiet, ten_sp, gia_sp, thongtin_ngan, giamgia FROM san_pham where ma_sp like '$masp'";
  $result = mysqli_query($conn, $sql);

  if (!$result) {
    die("Lỗi truy vấn: " . mysqli_error($conn));
  }

  $row = mysqli_fetch_assoc($result);
  $hinh_chi_tiet = $row['hinh_chi_tiet'];
  $hinh = $row['hinh'];
  $ten_sp = $row['ten_sp'];
  $gia_sp = $row['gia_sp'];
  $thongtin_ngan = $row['thongtin_ngan'];
  $giamgia = $row['giamgia'];
  $arr_hinh = explode(',', $hinh_chi_tiet);
  $discounted_price = $gia_sp * (1 - $giamgia / 100);

  ?>

  <script>
    // Lấy danh sách sản phẩm từ Local Storage (nếu có)
    var storedProducts = localStorage.getItem("products");

    // Kiểm tra xem danh sách sản phẩm đã tồn tại hay chưa
    if (storedProducts) {
      // Chuyển đổi chuỗi JSON thành mảng sản phẩm
      var products = JSON.parse(storedProducts);

      // Thêm sản phẩm mới vào mảng hiện có
      products.push({
        hinhChiTiet: "<?php echo $hinh; ?>",
        tenSp: "<?php echo $ten_sp; ?>",
        giaSp: "<?php echo $gia_sp; ?>",
        giamGia: "<?php echo $giamgia; ?>",
      });
    } else {
      // Tạo một mảng mới và thêm sản phẩm vào đó
      var products = [
        {
          hinhChiTiet: "<?php echo $hinh; ?>",
          tenSp: "<?php echo $ten_sp; ?>",
          giaSp: "<?php echo $gia_sp; ?>",
          giamGia: "<?php echo $giamgia; ?>",
        },
      ];
    }

    // Lưu danh sách sản phẩm mới vào Local Storage
    localStorage.setItem("products", JSON.stringify(products));
  </script>


  <!-- Beging container -->
  <div class="container">
    <div class="column-1">
      <div class="product-images" id="slide">
        <img src="<?php echo $arr_hinh[1]; ?>" alt="Ảnh nội dung" class="img-scale" id="hinh">
        <i class="fa fa-chevron-circle-left" id="btn_pre"></i>
        <i class="fa fa-chevron-circle-right" id="btn_next"></i>
      </div>
    </div>


    <div class="column-2">
      <h2>
        <?php echo $ten_sp; ?>
      </h2>
      <div class="product-price" style="color: var(--primary-color); font-size: 1.2rem;">
        <?php echo number_format($discounted_price, 0, '.', '.') ?>đ/
        <span>
          <?php echo number_format($gia_sp, 0, '.', '.') ?>đ
        </span>
      </div>

      <p class="mota">Mô tả sản phẩm:</p>
      <span class="thongtinngan">
        <?php echo nl2br($thongtin_ngan); ?>
      </span>
      <div class="btn">
        <button id="chonmua" class="btn_chonmua">Chọn mua</button>
        <button id="giohang" class="btn_giohang">Xem giỏ hàng</button>
      </div>

    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(document).ready(function () {
      var index = 0;
      var arr_hinh = <?php echo json_encode($arr_hinh); ?>;

      function chuyenAnh() {
        index++;
        if (index >= arr_hinh.length) index = 0;
        $("#hinh").attr("src", arr_hinh[index]);
      }

      $("#btn_pre").on("click", function () {
        index--;
        if (index < 0) index = arr_hinh.length - 1;
        $("#hinh").attr("src", arr_hinh[index]);
      });

      $("#btn_next").on("click", function () {
        chuyenAnh();
      });

      setInterval(chuyenAnh, 1500);
    });
    $(document).ready(function () {
      $("#chonmua").on("click", function () {
        var result = confirm("Sản phẩm đã được thêm vào giỏ hàng. Bạn có muốn xem giỏ hàng không?");

        // Xử lý kết quả từ người dùng
        if (result) {
          window.location.href = "./giohang.php";
        } 
      })
    })

    $(document).ready(function () {
      $("#giohang").on("click", function () {
        window.location.href = "./giohang.php";
      })
    })

  </script>
  <!-- End container -->


  <!-- Beging Footer -->
  <footer>
    <div class="row">
      <div class="col-md-3">
        <h4 class="footer_title">Thông tin liên hệ</h4>
        <p>Tâm An - Nhà thuốc vì sức khỏe mọi người</p>
        <hr>
        <p><i class="fas fa-map-marker-alt"></i>Địa chỉ: Khóm 4, Phường 6 Tp.Cao Lãnh, Đồng Tháp</p>
        <p><i class="fas fa-phone"></i>Số điện thoại: 0564056521</p>
        <p><i class="fas fa-envelope"></i>Email: kaicapro@gmail.com</p>
      </div>
      <div class="col-md-3">
        <h4 class="footer_title">Hỗ trợ khách hàng</h4>
        <ul>
          <li><a href="./gioithieu.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Giới thiệu
              <hr>
            </a></li>
          <li> <a href="./chinhsachdoitra.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Chính sách đổi trả
              <hr>
            </a></li>
          <li> <a href="./chinhsachbaomat.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Chính sách bảo mật
              <hr>
            </a></li>
          <li> <a href="./chinhsachgiaohang.html">
              <i class="fa-sharp fa-solid fa-sort-down"></i>
              Chính sách giao hàng
              <hr>
            </a></li>
        </ul>
      </div>
      <div class="col-md-3">
        <h4 class="footer_title">Tìm kiếm nhanh</h4>
        <ul>
          <li><button id="chuyentrang_tpcn">Thực phẩm chức năng</button></li>
          <li><button id="chuyentrang_tbyt">Dụng cụ y tế</button></li>
          <li>
            <img src="./img/bct.png" alt="Ảnh Bộ Công Thương" width="100px" height="10%" style="margin: -16px 0;">
            <p>GCN ĐĐKKDT SỐ 0672/HCM-DDKKDDD,
              22/07/2014, SỞ Y TẾ TP.HCM</p>
          </li>
        </ul>
      </div>
      <div class="col-md-3">
        <h4 class="footer_title">Ưu đãi hấp dẫn</h4>
        <ul>
          <li>Mỗi tháng chúng tôi đều có những đợt giảm giá dịch vụ và sản phẩm nhằm tri ân khách hàng. Để có thể cập
            nhật kịp thời những đợt giảm giá này, vui lòng nhập số điện thoại của bạn vào ô dưới đây.</li>
          <li><input id="emai_tv" type="text" placeholder="Để lại email để được tư vấn"><i id="email_tuvan"
              class="fas fa-paper-plane"></i></li>
        </ul>
      </div>
    </div>
    <hr>
    <p class="copy_right">Copyrights © 2023 by Truong An. Powered by Tâm An</p>
  </footer>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script>
    $(document).ready(function () {
      $("#email_tuvan").on("click", function () {
        var email_tv = $("#emai_tv").val(); // Lấy giá trị từ phần tử input có id "emai_tv"
        var trimmedEmail = email_tv.trim();
        $.ajax({
          type: "POST",
          url: "./sendmail_tuvan.php",
          data: { email: trimmedEmail },
          success: function (data) {
            Swal.fire({
              icon: 'success',
              title: 'Thông báo',
              text: 'Thông tin tư vấn đã gửi về mail của bạn. Vui lòng xem email!',
              showConfirmButton: false,
              timer: 0 // Tắt sau 2 giây
            });
          }
        })
      })

      // nhấn nút chuyển trang
      $("#chuyentrang_tpcn").on("click", function(){
        window.location.href = "./sanpham.php";
      })
      $("#chuyentrang_tbyt").on("click", function(){
        window.location.href = "./sanpham.php";
      })
    })
  </script>
  <!-- End Footer -->
</body>

</html>