<?php
include 'connect.php';

$select_ma = "SELECT ma_hoadon from hoadon order by ma_hoadon desc limit 1";
$result_query = mysqli_query($conn, $select_ma);
$result_ma = mysqli_fetch_assoc($result_query);
$ma = $result_ma["ma_hoadon"];

// Tách số cuối cùng của chuỗi
$last_number = substr($ma, -2); // "01"

// Tăng số cuối cùng lên 1
$new_number = sprintf("%02d", intval($last_number) + 1); // "02"

// Tạo mã mới
$new_id = "hoadon" . $new_number; // "hoadon01"
$email = $_POST['email'];
$ngaymua = $_POST['ngaythang'];
$tongtien = $_POST['tongtien'];
$trangthai = "Chưa duyệt";
$diachi = $_POST['diachi'];

// $sql = "INSERT INTO `hoadon` (`ma_hoadon`, `email_kh`, `ngaymua`, `tongtien`, `trangthai`, `diachigiaohang`) 
// VALUES ('.$new_id.', '.$email.', '.$ngaymua.', '.$tongtien.', '.$trangthai.', '.$diachi.');";

$sql = "INSERT INTO `hoadon` (`ma_hoadon`, `email_kh`, `ngaymua`, `tongtien`, `trangthai`, `diachigiaohang`) 
VALUES ('$new_id', '$email', '$ngaymua', '$tongtien', '$trangthai', '$diachi');";


$query = mysqli_query($conn, $sql);
if($query){
    echo "Thêm thành công";
}else{
    echo "Thêm thất bại";
}

?>