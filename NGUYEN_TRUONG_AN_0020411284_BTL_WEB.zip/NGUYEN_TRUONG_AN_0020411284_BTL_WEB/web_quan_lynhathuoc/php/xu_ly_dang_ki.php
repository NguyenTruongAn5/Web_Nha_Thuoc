<?php
include 'connect.php';

$email = $_POST['email'];

// Kiểm tra xem tài khoản đã tồn tại trong cơ sở dữ liệu chưa
$sql_check = "SELECT * FROM khachhang WHERE email = '$email'";
$query_check = mysqli_query($conn, $sql_check);

if (mysqli_num_rows($query_check) > 0) {
    echo "Tài khoản đã tồn tại";
} else {
    // Tiếp tục tạo tài khoản mới
    // Lấy mã sản phẩm
    $select_ma = "SELECT ma_kh from khachhang order by ma_kh desc limit 1";
    $result_query = mysqli_query($conn, $select_ma);
    $result_ma = mysqli_fetch_assoc($result_query);
    $ma = $result_ma["ma_kh"];

    // Tách số cuối cùng của chuỗi
    $last_number = substr($ma, -1); // "01"

    // Tăng số cuối cùng lên 1
    $new_number = sprintf("%01d", intval($last_number) + 1);

    // Tạo dữ liệu mới
    $phone = $_POST["phone"];
    $pass = md5($_POST["pass"]);
    $name = $_POST["name"];
    $new_id = "khachhang".$new_number;
    $quyen = "khach";

    $sql_insert = "INSERT INTO `khachhang` (`ma_kh`, `ten_kh`, `sdt`, `quyen`, `matkhau`, `email`) VALUES ('".$new_id."', '".$name."', '".$phone."', '".$quyen."', '".$pass."', '".$email."')";

    $query_insert = mysqli_query($conn, $sql_insert);
    if ($query_insert) {
        echo "Đã tạo tài khoản thành công";
    } else {
        echo "Đã tạo tài khoản thất bại";
    }
}

?>
