<?php
// Thông tin kết nối đến cơ sở dữ liệu
include "connect.php";

$search = $_POST['search'];
// Lấy dữ liệu từ cơ sở dữ liệu
$sql = "SELECT * FROM san_pham where `san_pham`.`ten_sp` like '%$search%'"; 
$result = mysqli_query($conn, $sql);
// Kiểm tra kết quả truy vấn
$table = '
<div class="cart_product_title scrollbar">
<table>
<thead class="table_fixed">
  <tr>
    <th>Mã SP</th>
    <th>Tên SP</th>
    <th>Giá SP</th>
    <th>Giảm giá</th>
    <th>Thông tin ngắn</th>
    <th>Thông tin chi tiết</th>
    <th>Loại SP</th>
    <th>Cách đóng gói</th>
    <th>Số lượng</th>
    <th>Lượt mua</th>
    <th>Hình SP</th>
    <th></th>
  </tr>
</thead>
<tbody>';

// Kiểm tra kết quả truy vấn
if (mysqli_num_rows($result) > 0) {
  while ($row = mysqli_fetch_assoc($result)) {
    // Lấy thông tin sản phẩm từ cơ sở dữ liệu
    $ma = $row["ma_sp"];
    $ten = $row["ten_sp"];
    $gia = $row["gia_sp"];
    $giamgia = $row["giamgia"];
    $anh = $row["hinh"];
    $thongtinngan = $row["thongtin_ngan"];
    $chitiet = $row["thongtinchitiet"];
    $loaithuoc = $row["loai_sp"];
    $dong_goi = $row["dong_goi"];
    $soluong = $row["so_luong"];
    $luotmua = $row["luot_mua"];

    // Thêm dữ liệu sản phẩm vào biến $table
    $table .= '
      <tr>
        <td id="ma_sp">' . $ma . '</td>
        <td>' . $ten . '</td>
        <td>' . $gia . '</td>
        <td>' . $giamgia . '</td>
        <td class="thongin">' . $thongtinngan . '</td>
        <td class="thongin">' . $chitiet . '</td>
        <td>' . $loaithuoc . '</td>
        <td>' . $dong_goi . '</td>
        <td>' . $soluong . '</td>
        <td>' . $luotmua . '</td>
        <td><img src="' . $anh . '" alt="Hình sản phẩm" width="120px" height="40px"></td>
        <td>
          <button class="button_del" value="' . $ma . '"><i class="fa-solid fa-trash"></i></button>
          <button class="btn_update" value ="' . $ma . '@' . $ten . '@' . $gia . '@' . $giamgia . '@' . $thongtinngan . '@' . $chitiet . '@' . $loaithuoc . '@' . $dong_goi . '@' . $soluong . '@' . $anh . '"><i class="fa-solid fa-pen-to-square"></i></button>
        </td>
      </tr>';
  }
} else {
  // Xử lý trường hợp không có dữ liệu
  $table .= '<tr><td colspan="12">Không có dữ liệu</td></tr>';
}

$table .= '</tbody></table></div>';

// In dữ liệu sản phẩm ra màn hình
echo $table;

// Đóng kết nối đến cơ sở dữ liệu
$conn->close();
?>