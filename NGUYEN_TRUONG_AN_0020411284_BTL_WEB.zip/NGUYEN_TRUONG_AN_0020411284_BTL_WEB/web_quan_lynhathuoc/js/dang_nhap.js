$(document).ready(function () {

  $("#dangnhap").on("click", function () {
    var acc = $.trim($("#taikhoan").val());
    var pass = $.trim($("#pass").val());
    $.post('./php/dang_nhap.php', { acc: acc, pass: pass }, function (data) {
      $("#page_admin").html(data);
    })
    $("#content").hide();
    event.preventDefault();
  })

  
})

