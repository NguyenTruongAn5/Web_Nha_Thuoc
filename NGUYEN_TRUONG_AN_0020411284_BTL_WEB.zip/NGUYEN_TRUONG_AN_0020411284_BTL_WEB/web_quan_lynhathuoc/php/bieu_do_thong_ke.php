<section id="hien_thong_ke" class="my-5">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 mb-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Lượt truy cập</h5>
            <p class="card-text">
              <?php
              // Kết nối đến cơ sở dữ liệu 
              include "./connect.php";
              // Lấy số lượt truy cập hiện tại
              $sql = "SELECT so_luot FROM luot_truy_cap WHERE id = 1";
              $result = mysqli_query($conn, $sql);
              $row = mysqli_fetch_assoc($result);
              $so_luot = $row["so_luot"];

              // Hiển thị số lượt truy cập
              echo "Số lượt truy cập: " . $so_luot;
              ?>

            </p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 mb-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Số lượng người dùng</h5>
            <p class="card-text">
              <?php
              include "./connect.php";
              $sql = "SELECT * FROM khachhang Where quyen like 'khach'";
              $result = mysqli_query($conn, $sql);
              $tongkh = mysqli_num_rows($result);

              echo $tongkh;
              ?>
            </p>
          </div>
        </div>
      </div>
      <div class="col-lg-4 mb-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Doanh thu</h5>
            <p class="card-text">
              <?php
              include "./connect.php";
              $sql = "SELECT tongtien FROM hoadon";
              $result = mysqli_query($conn, $sql);
              $tongtien = 0;
              if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                  $tongtien += $row["tongtien"];
                }
              }
              $tongtien_formatted = number_format($tongtien, 0, ",", ".");
              echo $tongtien_formatted . " đ";
              ?>


            </p>
          </div>
        </div>
      </div>
    </div>
  </div>


  

</section>