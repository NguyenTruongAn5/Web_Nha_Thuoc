<?php
// Thông tin kết nối đến cơ sở dữ liệu
include "./connect.php";

// Số sản phẩm hiển thị trên một trang
$products_per_page = 8;

// Lấy tham số trang hiện tại từ URL
$current_page = isset($_GET['page']) ? intval($_GET['page']) : 1;

// Tính vị trí bắt đầu và số sản phẩm hiển thị trên trang hiện tại
$start_index = ($current_page - 1) * $products_per_page;

// Lấy dữ liệu từ cơ sở dữ liệu
$sql = "SELECT ma_sp, ten_sp, hinh, giamgia, gia_sp, dong_goi FROM san_pham where gia_sp < 100000 LIMIT $start_index, $products_per_page";
$result = mysqli_query($conn, $sql);

// Kiểm tra kết quả truy vấn
if (mysqli_num_rows($result) > 0) {
    // Hiển thị các sản phẩm
    while ($row = mysqli_fetch_assoc($result)) {
        $image = $row["hinh"];
        $price = $row["gia_sp"];
        $discount = $row["giamgia"];
        $name = $row["ten_sp"];
        $dong_goi = $row["dong_goi"];
        $ma_sp = $row["ma_sp"];

        // Tính toán giá sau khi giảm giá
        $discounted_price = $price * (1 - $discount / 100);

        // Thay thế các giá trị vào đoạn mã HTML
        $html = '<div class="product-card">
                  <div class="discount-percent">-' . $discount . '%</div>
                  <a href="">
                    <img src="' . $image . '" alt="' . $name . '" width="100%" height="100%">
                  </a>
                  <div class="product-count">' . $dong_goi . '</div>
                  <h3 class="product-name">' . $name . '</h3>
                  <div class="product-price">' . number_format($discounted_price, 0, '.', '.') . 'đ/
                    <span>' . number_format($price, 0, '.', '.') . 'đ</span>
                  </div>
                  <a target="_blank" href="chitietsp.php?masp='.$ma_sp.'" style="text-decoration: none;">
                  <button class="buy-now-button">Mua Ngay</button>
                  </a>
                </div>';
        echo $html;
    }

    // Tạo nút phân trang
    $sql = "SELECT COUNT(*) AS total FROM san_pham where gia_sp < 100000 ";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    $total_products = $row['total'];
    $total_pages = ceil($total_products / $products_per_page);

    echo '<div class="pagination">';
    if ($total_pages > 1) {
        // Nút trở về trang đầu
        if ($current_page > 1) {
            echo '<a href="?page=1">&laquo;</a>';
        }

        // Số lượng nút phân trang cần hiển thị
        $num_buttons = 3;

        // Tính toán vị trí bắt đầu và kết thúc của các nút phân trang
        $start_page = max(1, $current_page - $num_buttons);
        $end_page = min($total_pages, $current_page + $num_buttons);

        // Hiển thị các nút phân trang
        for ($i = $start_page; $i <= $end_page; $i++) {
            if ($i == $current_page) {
                echo '<a class="active" href="#">' . $i . '</a>';
            } else {
                echo '<a href="?page=' . $i . '">' . $i . '</a>';
            }
        }

        // Nút trang cuối cùng
        if ($current_page < $total_pages) {
            echo '<a href="?page=' . $total_pages . '">&raquo;</a>';
        }
    }
    echo '</div>';


} else {
    echo "Không có dữ liệu";
}

// Đóng kết nối đến cơ sở dữ liệu
$conn->close();
?>