<?php

include 'connect.php';

$new_id = $_POST['id']; // "sanpham01"
$tensp = $_POST['tensp'];
$giasp = $_POST['giasp'];
$giamgia = $_POST['giamgia'];
$thongtinngan = $_POST['thongtinngan'];
$thongtinchitiet = $_POST['thongtinchitiet'];
$loaisp = $_POST['loaisp'];
$cachdonggoi = $_POST['cachdonggoi'];
$soluong = $_POST['soluong'];
$hinhsp = $_POST['hinhsp'];
$luotmua = 0;

echo $new_id;
$sql = "UPDATE `san_pham` 
SET `ten_sp` = '$tensp', 
    `gia_sp` = '$giasp', 
    `giamgia` = '$giamgia', 
    `hinh` = '$hinhsp', 
    `thongtin_ngan` = '$thongtinngan', 
    `thongtinchitiet` = '$thongtinchitiet', 
    `loai_sp` = '$loaisp', 
    `dong_goi` = '$cachdonggoi', 
    `so_luong` = '$soluong', 
    `luot_mua` = '$luotmua',
    `hinh_chi_tiet` = '$hinhsp'  
WHERE `ma_sp` = '$new_id'";



$query = mysqli_query($conn, $sql);
if ($query) {
    echo "Cập nhật thành công";
} else {
    echo "Cập nhật thất bại";
}

?>